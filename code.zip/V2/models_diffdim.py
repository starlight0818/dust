import torch.nn as nn
import torch
from V0.modules import Transformer_Encoder, Cross_Transformer_Encoder, Cross_Transformer_Encoder_Cross_Position
from V2.modules import Syntax_Aware_Transformer_Encoder
from fastNLP.modules import ConditionalRandomField
import collections
from utils import get_crf_zero_init
from fastNLP import seq_len_to_mask
from utils import print_info
from utils import better_init_rnn
from fastNLP.modules import LSTM
import math
import copy
from utils import size2MB
from utils import MyDropout

def get_embedding(max_seq_len, embedding_dim, padding_idx=None, rel_pos_init=0):
    """Build sinusoidal embeddings.
    This matches the implementation in tensor2tensor, but differs slightly
    from the description in Section 3.5 of "Attention Is All You Need".
    rel pos init:
    如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
    如果是1，那么就按-max_len,max_len来初始化
    """
    num_embeddings = 2*max_seq_len+1
    half_dim = embedding_dim // 2
    emb = math.log(10000) / (half_dim - 1)
    emb = torch.exp(torch.arange(half_dim, dtype=torch.float) * -emb)
    if rel_pos_init == 0:
        emb = torch.arange(num_embeddings, dtype=torch.float).unsqueeze(1) * emb.unsqueeze(0)
    else:
        emb = torch.arange(-max_seq_len,max_seq_len+1, dtype=torch.float).unsqueeze(1)*emb.unsqueeze(0)
    emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1).view(num_embeddings, -1)
    if embedding_dim % 2 == 1:
        # zero pad
        emb = torch.cat([emb, torch.zeros(num_embeddings, 1)], dim=1)
    if padding_idx is not None:
        emb[padding_idx, :] = 0
    return emb


class Absolute_SE_Position_Embedding(nn.Module):
    def __init__(self,fusion_func,hidden_size,learnable,mode=collections.defaultdict(bool),pos_norm=False,max_len=5000,):
        '''

        :param fusion_func:暂时只有add和concat(直接拼接然后接线性变换)，
        后续得考虑直接拼接再接非线性变换，和将S和E两个位置做非线性变换再加或拼接
        :param hidden_size:
        :param learnable:
        :param debug:
        :param pos_norm:
        :param max_len:
        '''
        super().__init__()
        self.fusion_func = fusion_func
        assert self.fusion_func in {'add','concat','nonlinear_concat','nonlinear_add','add_nonlinear','concat_nonlinear'}
        self.pos_norm = pos_norm
        self.mode = mode
        self.hidden_size = hidden_size
        pe = get_embedding(max_len,hidden_size)
        pe_sum = pe.sum(dim=-1,keepdim=True)
        if self.pos_norm:
            with torch.no_grad():
                pe = pe / pe_sum
        # pe = pe.unsqueeze(0)
        pe_s = copy.deepcopy(pe)
        pe_e = copy.deepcopy(pe)
        self.pe_s = nn.Parameter(pe_s, requires_grad=learnable)
        self.pe_e = nn.Parameter(pe_e, requires_grad=learnable)
        if self.fusion_func == 'concat':
            self.proj = nn.Linear(self.hidden_size * 3,self.hidden_size)

        if self.fusion_func == 'nonlinear_concat':
            self.pos_proj = nn.Sequential(nn.Linear(self.hidden_size * 2,self.hidden_size),
                                          nn.LeakyReLU(),
                                          nn.Linear(self.hidden_size,self.hidden_size))
            self.proj = nn.Linear(self.hidden_size * 2,self.hidden_size)

        if self.fusion_func == 'nonlinear_add':
            self.pos_proj = nn.Sequential(nn.Linear(self.hidden_size * 2,self.hidden_size),
                                          nn.LeakyReLU(),
                                          nn.Linear(self.hidden_size,self.hidden_size))

        if self.fusion_func == 'concat_nonlinear':
            self.proj = nn.Sequential(nn.Linear(self.hidden_size * 3,self.hidden_size),
                                      nn.LeakyReLU(),
                                      nn.Linear(self.hidden_size,self.hidden_size))

        if self.fusion_func == 'add_nonlinear':
            self.proj = nn.Sequential(nn.Linear(self.hidden_size,self.hidden_size),
                                      nn.LeakyReLU(),
                                      nn.Linear(self.hidden_size,self.hidden_size))


    def forward(self,inp,pos_s,pos_e):
        batch = inp.size(0)
        max_len = inp.size(1)
        pe_s = self.pe_s.index_select(0, pos_s.view(-1)).view(batch,max_len,-1)
        pe_e = self.pe_e.index_select(0, pos_e.view(-1)).view(batch,max_len,-1)

        if self.fusion_func == 'concat':
            inp = torch.cat([inp,pe_s,pe_e],dim=-1)
            output = self.proj(inp)
        elif self.fusion_func == 'add':
            output = pe_s + pe_e + inp
        elif self.fusion_func == 'nonlinear_concat':
            pos = self.pos_proj(torch.cat([pe_s,pe_e],dim=-1))
            output = self.proj(torch.cat([inp,pos],dim=-1))
        elif self.fusion_func == 'nonlinear_add':
            pos = self.pos_proj(torch.cat([pe_s,pe_e],dim=-1))
            output = pos + inp
        elif self.fusion_func == 'add_nonlinear':
            inp = inp + pe_s + pe_e
            output = self.proj(inp)

        elif self.fusion_func == 'concat_nonlinear':
            output = self.proj(torch.cat([inp,pe_s,pe_e],dim=-1))



        return output

        # if self.fusion_func == 'add':
        #     result =

    def get_embedding(max_seq_len, embedding_dim, padding_idx=None, rel_pos_init=0):
        """Build sinusoidal embeddings.
        This matches the implementation in tensor2tensor, but differs slightly
        from the description in Section 3.5 of "Attention Is All You Need".
        rel pos init:
        如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化
        """
        num_embeddings = 2 * max_seq_len + 1
        half_dim = embedding_dim // 2
        emb = math.log(10000) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, dtype=torch.float) * -emb)
        if rel_pos_init == 0:
            emb = torch.arange(num_embeddings, dtype=torch.float).unsqueeze(1) * emb.unsqueeze(0)
        else:
            emb = torch.arange(-max_seq_len, max_seq_len + 1, dtype=torch.float).unsqueeze(1) * emb.unsqueeze(0)
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1).view(num_embeddings, -1)
        if embedding_dim % 2 == 1:
            # zero pad
            emb = torch.cat([emb, torch.zeros(num_embeddings, 1)], dim=1)
        if padding_idx is not None:
            emb[padding_idx, :] = 0
        return emb

class Absolute_Position_Embedding(nn.Module):
    def __init__(self,fusion_func,hidden_size,learnable,mode=collections.defaultdict(bool),pos_norm=False,max_len=5000):
        '''

        :param hidden_size:
        :param max_len:
        :param learnable:
        :param debug:
        :param fusion_func:暂时只有add和concat(直接拼接然后接线性变换)，后续得考虑直接拼接再接非线性变换
        '''
        super().__init__()
        self.fusion_func = fusion_func
        assert ('add' in self.fusion_func) != ('concat' in self.fusion_func)
        if 'add' in self.fusion_func:
            self.fusion_func = 'add'
        else:
            self.fusion_func = 'concat'
        #备注，在SE绝对位置里，会需要nonlinear操作来融合两种位置pos，但普通的不需要，所以只根据字符串里有哪个关键字来判断
        self.pos_norm = pos_norm
        self.mode = mode
        self.debug = mode['debug']
        self.hidden_size = hidden_size
        pe = get_embedding(max_len,hidden_size)
        # pe = torch.zeros(max_len, hidden_size,requires_grad=True)
        # position = torch.arange(0, max_len).unsqueeze(1).float()
        # div_term = torch.exp(torch.arange(0, hidden_size, 2,dtype=torch.float32) *
        #                      -(math.log(10000.0) / float(hidden_size)))
        # pe[:, 0::2] = torch.sin((position * div_term))
        # pe[:, 1::2] = torch.cos(position * div_term)
        pe_sum = pe.sum(dim=-1,keepdim=True)
        if self.pos_norm:
            with torch.no_grad():
                pe = pe / pe_sum
        pe = pe.unsqueeze(0)
        self.pe = nn.Parameter(pe, requires_grad=learnable)

        if self.fusion_func == 'concat':
            self.proj = nn.Linear(self.hidden_size * 2,self.hidden_size)

        if self.mode['debug']:
            print_info('position embedding:')
            print_info(self.pe[:100])
            print_info('pe size:{}'.format(self.pe.size()))
            print_info('pe avg:{}'.format(torch.sum(self.pe)/(self.pe.size(2)*self.pe.size(1))))
    def forward(self,inp):
        batch = inp.size(0)
        if self.mode['debug']:
            print_info('now in Absolute Position Embedding')
        if self.fusion_func == 'add':
            output = inp + self.pe[:,:inp.size(1)]
        elif self.fusion_func == 'concat':
            inp = torch.cat([inp,self.pe[:,:inp.size(1)].repeat([batch]+[1]*(inp.dim()-1))],dim=-1)
            output = self.proj(inp)

        return output

    @staticmethod
    def get_embedding(num_embeddings, embedding_dim, padding_idx=None):
        """Build sinusoidal embeddings.
        This matches the implementation in tensor2tensor, but differs slightly
        from the description in Section 3.5 of "Attention Is All You Need".
        """
        half_dim = embedding_dim // 2
        emb = math.log(10000) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, dtype=torch.float) * -emb)
        emb = torch.arange(num_embeddings, dtype=torch.float).unsqueeze(1) * emb.unsqueeze(0)
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1).view(num_embeddings, -1)
        if embedding_dim % 2 == 1:
            # zero pad
            emb = torch.cat([emb, torch.zeros(num_embeddings, 1)], dim=1)
        if padding_idx is not None:
            emb[padding_idx, :] = 0
        return emb

class Cross_Lattice_Transformer_SeqLabel(nn.Module):
    def __init__(self,lattice_embed, phrase_lattice_embed , bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos,use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',
                 four_pos_shared=True,four_pos_fusion=None,four_pos_fusion_shared=True,
                 bert_embedding=None,use_pytorch_dropout=False,
                 residual = 'no'):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化

        :param embed_dropout_pos: 如果是0，就直接在embed后dropout，是1就在embed变成hidden size之后再dropout，
        是2就在绝对位置加上之后dropout
        '''
        super().__init__()
        self.use_pytorch_dropout = use_pytorch_dropout
        self.four_pos_fusion_shared = four_pos_fusion_shared
        self.mode = mode
        self.four_pos_shared = four_pos_shared
        self.abs_pos_fusion_func = abs_pos_fusion_func

        self.lattice_embed = lattice_embed
        self.phrase_lattice_embed = phrase_lattice_embed

        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        # self.relative_position = relative_position
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        if self.use_rel_pos:
            assert four_pos_fusion is not None
        self.four_pos_fusion = four_pos_fusion
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init
        self.embed_dropout_pos = embed_dropout_pos


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)

        # if self.add_position:
        #     print('暂时只支持位置编码的concat模式')
        #     exit(1208)

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None

        if self.use_abs_pos:
            self.abs_pos_encode = Absolute_SE_Position_Embedding(self.abs_pos_fusion_func,
                                        self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                        pos_norm=self.pos_norm)

        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
            if self.four_pos_shared:
                self.pe_ss = self.pe
                self.pe_se = self.pe
                self.pe_es = self.pe
                self.pe_ee = self.pe
            else:
                self.pe_ss = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_se = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_es = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_ee = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
        else:
            self.pe = None
            self.pe_ss = None
            self.pe_se = None
            self.pe_es = None
            self.pe_ee = None






        # if self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        if self.use_bigram:
            self.bigram_size = self.bigram_embed.embedding.weight.size(1) # bigram.weight.shape:[107941, 50], size(1):50
            # lattice.weight.shape: [33357, 50], self.char_input_size:100, phrase.weight.shape:[39424, 50]
            self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            self.char_input_size = self.lattice_embed.embedding.weight.size(1)

        self.lex_input_size = self.lattice_embed.embedding.weight.size(1) #50

        if use_pytorch_dropout:
            self.embed_dropout = nn.Dropout(self.dropout['embed'])
            self.gaz_dropout = nn.Dropout(self.dropout['gaz'])
            self.output_dropout = nn.Dropout(self.dropout['output'])
        else:
            self.embed_dropout = MyDropout(self.dropout['embed'])
            self.gaz_dropout = MyDropout(self.dropout['gaz'])
            self.output_dropout = MyDropout(self.dropout['output'])


        self.char_proj = nn.Linear(self.char_input_size,self.hidden_size)
        self.lex_proj = nn.Linear(self.lex_input_size,self.hidden_size)

        self.residual = residual

        self.encoder = self.get_encoder()
        self.phrase_encoder = self.get_encoder()

        self.cross_encoder = self.get_encoder()

        # self.output = nn.Linear(self.hidden_size,self.label_size)
        self.output = nn.Linear(self.hidden_size*2,self.label_size)

        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
        self.batch_num = 0

    def get_encoder(self):
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)


    def forward(self, lattice, phrase_lattice, bigrams, seq_len, lex_num, phrase_num, pos_s, pos_e, phrase_pos_s, phrase_pos_e,
                target, chars_target=None):
        # if self.training:
        #     self.batch_num+=1
        # if self.batch_num == 1000:
        #     exit()

        # print('lattice:')
        # print(lattice)
        
        # initial返回的结果中，只有emb不一样
        batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters(lattice, bigrams, seq_len, lex_num, pos_s, pos_e)
        batch_size, max_seq_len, dim2, dim3, phrase_embedding = self.initial_parameters(phrase_lattice, bigrams, seq_len, phrase_num, phrase_pos_s, phrase_pos_e, is_phrase=True)

        encoded = self.encoder(embedding,embedding,embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                               print_=(self.batch_num==327))

        phrase_encoded = self.phrase_encoder(phrase_embedding,phrase_embedding,phrase_embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
                               print_=(self.batch_num==327))

        encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
        phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
        # pos_e.shape: [10, 196]; phrase_pos_s.shape: [10, 219]
        pos_s = pos_s[:,:max_seq_len]
        pos_e = pos_e[:,:max_seq_len]
        encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num=0,pos_s=pos_s,pos_e=pos_s)
        phrase_encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,lex_num=0,pos_s=pos_s,pos_e=pos_s)

        if self.batch_num == 327:
            print('{} encoded:{}'.format(self.batch_num,
                                       encoded[:2,dim2,:dim3]))

        
        # if hasattr(self,'output_dropout'):
        #     encoded = self.output_dropout(encoded)
        #     phrase_encoded = self.output_dropout(phrase_encoded)

        # encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
        # phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
        # encoded = torch.cat([encoded, phrase_encoded], dim=-1)

        if hasattr(self,'output_dropout'):
            encoded_cross = self.output_dropout(encoded_cross)
            phrase_encoded_cross = self.output_dropout(phrase_encoded_cross)

        encoded = torch.cat([encoded_cross, phrase_encoded_cross], dim=-1)

        pred = self.output(encoded)

        if self.batch_num == 327:
            print('{} pred:{}'.format(self.batch_num,
                                       pred[:2,dim2,:dim3]))

        # print('pred:{}'.format(pred[:,dim2,:dim3]))
        # exit()

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss

            if self.batch_num == 327:
                print('{} loss:{}'.format(self.batch_num,loss))
                exit()

            # exit()
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result

    def initial_parameters(self, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]

        if not is_phrase:
            # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
            raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
            #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        else:
            raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]

        embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

class Concat_Lattice_Transformer_SeqLabel(nn.Module):
    def __init__(self, online, char_embed, words_embed, phrases_embed, bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos,use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',
                 four_pos_shared=True,four_pos_fusion=None,four_pos_fusion_shared=True,
                 bert_embedding=None,
                #  bert_embedding_phrase=None,
                 use_pytorch_dropout=False,
                 residual = 'no'):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化

        :param embed_dropout_pos: 如果是0，就直接在embed后dropout，是1就在embed变成hidden size之后再dropout，
        是2就在绝对位置加上之后dropout
        '''
        super().__init__()

        # bert和非bert的不同之处
        self.use_bert = False
        if bert_embedding is not None:
            self.use_bert = True
            self.bert_embedding = bert_embedding
        # if bert_embedding_phrase is not None:
        #     self.bert_embedding_phrase = bert_embedding_phrase

        self.use_pytorch_dropout = use_pytorch_dropout
        self.four_pos_fusion_shared = four_pos_fusion_shared
        self.mode = mode
        self.four_pos_shared = four_pos_shared
        self.abs_pos_fusion_func = abs_pos_fusion_func

        # self.lattice_embed = lattice_embed
        # self.phrase_lattice_embed = phrase_lattice_embed

        # self.lattice_embed = lattice_embed
        self.words_embed = words_embed
        # self.phrase_lattice_embed = phrase_lattice_embed
        self.char_embed = char_embed
        self.phrases_embed = phrases_embed

        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        # self.relative_position = relative_position
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        if self.use_rel_pos:
            assert four_pos_fusion is not None
        self.four_pos_fusion = four_pos_fusion
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init
        self.embed_dropout_pos = embed_dropout_pos


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)

        # if self.add_position:
        #     print('暂时只支持位置编码的concat模式')
        #     exit(1208)

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None

        if self.use_abs_pos:
            self.abs_pos_encode = Absolute_SE_Position_Embedding(self.abs_pos_fusion_func,
                                        self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                        pos_norm=self.pos_norm)

        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
            if self.four_pos_shared:
                self.pe_ss = self.pe
                self.pe_se = self.pe
                self.pe_es = self.pe
                self.pe_ee = self.pe
            else:
                self.pe_ss = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_se = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_es = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_ee = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
        else:
            self.pe = None
            self.pe_ss = None
            self.pe_se = None
            self.pe_es = None
            self.pe_ee = None






        # if self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        

        if self.use_bigram:
            self.bigram_size = self.bigram_embed.embedding.weight.size(1) # bigram.weight.shape:[107941, 50], size(1):50
            # lattice.weight.shape: [33357, 50], self.char_input_size:100, phrase.weight.shape:[39424, 50]
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)

        # bert和非bert的不同之处
        if self.use_bert:
            self.char_input_size+=self.bert_embedding._embed_size

        # self.lex_input_size = self.lattice_embed.embedding.weight.size(1) #50
        # lex size是word size
        self.lex_input_size = self.words_embed.embedding.weight.size(1) #50
        # phrase可能是pretrained，也可能是online的
        if online == 'static':
            self.phrase_input_size = self.phrases_embed.embedding.weight.size(1) #50
        else:
            self.phrase_input_size = self.phrases_embed.embed_size 

        # general词典维度可能比char大。tencent的lex是200维，而yj-char只有50维。
        # 假设char和phrase的维度相等
        # 因为char和phrase都是50维，所以把lex也映射为50维吧。
        # TODO：lex和phrase没有分开做映射，都是用的lex_proj。
        char_size = self.char_embed.embedding.weight.size(1) # 这个char_size只是char的size，不包含bigram，bert等。
        assert char_size == self.phrase_input_size
        if self.char_embed.embedding.weight.size(1) != self.lex_input_size:
            self.lex_proj2char = nn.Linear(self.lex_input_size,char_size)    

        if use_pytorch_dropout:
            self.embed_dropout = nn.Dropout(self.dropout['embed'])
            self.gaz_dropout = nn.Dropout(self.dropout['gaz'])
            self.output_dropout = nn.Dropout(self.dropout['output'])
        else:
            self.embed_dropout = MyDropout(self.dropout['embed'])
            self.gaz_dropout = MyDropout(self.dropout['gaz'])
            self.output_dropout = MyDropout(self.dropout['output'])


        self.char_proj = nn.Linear(self.char_input_size,self.hidden_size)
        # char, phrase是50，lex从200也转换为50.
        # self.lex_proj = nn.Linear(self.lex_input_size,self.hidden_size)
        self.lex_proj = nn.Linear(self.phrase_input_size,self.hidden_size)

        self.residual = residual

        self.encoder = self.get_encoder()
        self.phrase_encoder = self.get_encoder()


        # self.cross_encoder = self.get_encoder()

        self.output = nn.Linear(self.hidden_size,self.label_size)
        # self.output = nn.Linear(self.hidden_size*2,self.label_size)

        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
        self.batch_num = 0

    def get_encoder(self):
        return Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                        #    use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)


    # def forward(self, chars, lattice, phrase_lattice, bigrams, seq_len, lex_num, phrase_num, pos_s, pos_e, phrase_pos_s, phrase_pos_e,
    #             target, chars_target=None):
    def forward(self, words, lattice, chars, phrases, phrase_lattice, bigrams, seq_len, lex_num, phrase_num, pos_s, pos_e, phrase_pos_s, phrase_pos_e,
                target, chars_target=None):
        # if self.training:
        #     self.batch_num+=1
        # if self.batch_num == 1000:
        #     exit()

        # print('lattice:')
        # print(lattice)
        
        # initial返回的结果中，只有emb不一样。max_seq_len是seq_len的最大值。dim2、dim3实际没啥作用，是debug用的。
        # batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters(lattice, bigrams, seq_len, lex_num, pos_s, pos_e)
        # batch_size, max_seq_len, dim2, dim3, phrase_embedding = self.initial_parameters(phrase_lattice, bigrams, seq_len, phrase_num, phrase_pos_s, phrase_pos_e, is_phrase=True)
        
        batch_size, max_seq_len, dim2, dim3, embedding = \
            self.initial_parameters_for_concat(chars, words, phrases, lattice, phrase_lattice, bigrams, seq_len, lex_num, phrase_num)

        # 这种方法即使维度对上了，但会遇到pad不对齐问题。
        # pos-all:(char+lex)(pad)+lex2(pad)
        # pos-phrase: lex(pad)+(char+lex2)(pad)
        # max_phrase_lattice_len = phrase_lattice.size(1)
        # max_phrase_len = max_phrase_lattice_len-max_seq_len
        # max_lattice_len = lattice.size(1)
        # max_lex_len = max_lattice_len - max_seq_len
        # pos_all_s = torch.cat([pos_s,torch.zeros(size=[batch_size,max_phrase_len]).to(pos_s)],dim=-1)
        # phrase_pos_s_for_all = torch.cat([torch.zeros(size=[batch_size,max_lex_len]).to(pos_s),phrase_pos_s],dim=-1)
        
        # 设置整体矩阵大小，填充矩阵时手动加pad
        # max_phrase_lattice_len = phrase_lattice.size(1)
        # max_phrase_len = max_phrase_lattice_len-max_seq_len
        # max_phrase_len = max(phrase_num)
        # max_lattice_len = lattice.size(1) # 和max_seq_len_and_lex_num的意思一样；这块没有使用
        # max_lex_len = max_lattice_len - max_seq_len
        # max_char_lex_phrase = max_lattice_len + max_phrase_len
        max_char_lex_phrase = max(seq_len+lex_num+phrase_num)
        
        # 最大长度为lattice_num+phrase_num，实际应该会比这个小一些
        # 因为实际中lattice后紧跟着phrase，最后加的pad，而非lattice之后就开始加pad
        # pos_all_s = torch.cat([pos_s,torch.zeros(size=[batch_size,max_phrase_len]).to(pos_s)],dim=-1)
        # pos_all_e = torch.cat([pos_e,torch.zeros(size=[batch_size,max_phrase_len]).to(pos_e)],dim=-1)

        pos_all_s = torch.zeros(size=[batch_size,max_char_lex_phrase]).to(pos_s)
        pos_all_e = torch.zeros(size=[batch_size,max_char_lex_phrase]).to(pos_e)

        for ind,(i,j,k) in enumerate(zip(seq_len,lex_num, phrase_num)):
            # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
            # lex_num是list，是每个instance匹配到词的个数。
            # 最后加pad，确保和lattice的维度一致。
            lattice_phrase_pos_s = torch.cat([pos_s[ind][:i+j],phrase_pos_s[ind][i:i+k]],dim=-1) # phrase_pos_s.shape [10, 219]
            pads_temp = torch.zeros(size=[max_char_lex_phrase-i-j-k]).to(pos_s) #[10,50]
            lattice_phrase_pads_pos_s = torch.cat([lattice_phrase_pos_s,pads_temp],dim=-1)
            pos_all_s[ind] = lattice_phrase_pads_pos_s

            lattice_phrase_pos_e = torch.cat([pos_e[ind][:i+j],phrase_pos_e[ind][i:i+k]],dim=-1) # phrase_pos_s.shape [10, 219]
            pads_temp_e = torch.zeros(size=[max_char_lex_phrase-i-j-k]).to(pos_e) #[10,50]
            lattice_phrase_pads_pos_e = torch.cat([lattice_phrase_pos_e,pads_temp_e],dim=-1)
            pos_all_e[ind] = lattice_phrase_pads_pos_e

        # seq_len是char的len, lex_num是lex的len
        # encoded = self.encoder(embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
        #                        print_=(self.batch_num==327))
        encoded = self.encoder(embedding,seq_len,lex_num=lex_num+phrase_num,pos_s=pos_all_s,pos_e=pos_all_e)

        # phrase_encoded = self.phrase_encoder(phrase_embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
        #                        print_=(self.batch_num==327))



        if self.batch_num == 327:
            print('{} encoded:{}'.format(self.batch_num,
                                       encoded[:2,dim2,:dim3]))

        
        if hasattr(self,'output_dropout'):
            encoded = self.output_dropout(encoded)
            # phrase_encoded = self.output_dropout(phrase_encoded)

        encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
        # phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
        # encoded = torch.cat([encoded, phrase_encoded], dim=-1)

        pred = self.output(encoded)

        if self.batch_num == 327:
            print('{} pred:{}'.format(self.batch_num,
                                       pred[:2,dim2,:dim3]))

        # print('pred:{}'.format(pred[:,dim2,:dim3]))
        # exit()

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss

            if self.batch_num == 327:
                print('{} loss:{}'.format(self.batch_num,loss))
                exit()

            # exit()
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result

    # 合并general lexicon和domain lexicon的emb，pos。
    def initial_parameters_for_concat(self, chars, words, phrases, lattice, phrase_lattice, bigrams, seq_len, lex_num, phrase_num):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)# phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        max_seq_len = bigrams.size(1)# bigrams.shape:[10,149]，字的最大长度
        
        # 设置整体矩阵大小，填充矩阵时手动加pad
        # max_phrase_lattice_len = phrase_lattice.size(1)
        # max_phrase_len = max_phrase_lattice_len-max_seq_len # 这么算有问题，max_phrase_len不一定是在lattice最大的时候得到。
        # max_phrase_len = max(phrase_num)
        # max_lattice_len = lattice.size(1) #和max_seq_len_and_lex_num的意思一样
        # max_lex_len = max_seq_len_and_lex_num - max_seq_len # 这么算有问题，max_lex_len不一定是在lattice最大的时候得到。
        # max_char_lex_phrase = max_seq_len_and_lex_num + max_phrase_len
        max_char_lex_phrase = max(seq_len+lex_num+phrase_num)

        # raw_embed_lattice = self.lattice_embed(lattice)
        # raw_embed_phrase_lattice = self.phrase_lattice_embed(phrase_lattice)
        raw_embed_chars = self.char_embed(chars)
        raw_embed_words = self.words_embed(words)
        raw_embed_phrases = self.phrases_embed(phrases)

        if self.char_embed.embedding.weight.size(1) != self.lex_input_size:
            raw_embed_words = self.lex_proj2char(raw_embed_words)

        # 最大长度为lattice_num+phrase_num，实际应该会比这个小一些
        # 因为实际中lattice后紧跟着phrase，最后加的pad，而非lattice之后就开始加pad
        # TODO: lex_input_size可能和phrase input size不同
        # char, phrase是50，lex从200也转换为50.
        # raw_embed = torch.zeros(size=[batch_size,max_char_lex_phrase,self.lex_input_size]).to(raw_embed_chars)
        raw_embed = torch.zeros(size=[batch_size,max_char_lex_phrase,self.phrase_input_size]).to(raw_embed_chars)

        # 手动给char+lex+phrase加pad
        for ind,(i,j,k) in enumerate(zip(seq_len, lex_num, phrase_num)):
            # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
            # lex_num是list，是每个instance匹配到词的个数。
            # 最后加pad，确保和lattice的维度一致。
            # lattice_phrase = torch.cat([raw_embed_lattice[ind][:i+j],raw_embed_phrase_lattice[ind][i:i+k]],dim=0) #[125, 50],[54, 50]->[179,50]
            # pads_temp = torch.zeros(size=[max_char_lex_phrase-i-j-k, self.lex_input_size]).to(raw_embed) #[10,50]
            # lattice_phrase_pads = torch.cat([lattice_phrase,pads_temp],dim=0)
            # raw_embed[ind] = lattice_phrase_pads
            lattice_construction = torch.cat([raw_embed_chars[ind][:i],raw_embed_words[ind][:j]],dim=0)
            lattice_phrase_construction = torch.cat([lattice_construction,raw_embed_phrases[ind][:k]],dim=0) #[125, 50],[54, 50]->[179,50]
            # char, phrase是50，lex从200也转换为50.
            pads_temp = torch.zeros(size=[max_char_lex_phrase-i-j-k, self.phrase_input_size]).to(raw_embed) #[10,50]
            # pads_temp = torch.zeros(size=[max_char_lex_phrase-i-j-k, self.lex_input_size]).to(raw_embed) #[10,50]
            lattice_phrase_pads = torch.cat([lattice_phrase_construction,pads_temp],dim=0)
            raw_embed[ind] = lattice_phrase_pads

        # 感觉这块好像用谁都无所谓，反正char emb是一样的，而lex部分后面也会mask掉。
        # if not is_phrase:
        #     # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
        #     raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
        #     #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        # else:
        #     raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
        # raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
        # raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        # raw_embed2 = self.phrase_lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]

        # if self.use_bigram:
        #     bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
        #     bigrams_embed = torch.cat([bigrams_embed,
        #                                torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
        #                                                  self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
        #     raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        # else:
        #     raw_embed_char = raw_embed

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_char_lex_phrase-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        else:
            raw_embed_char = raw_embed

        # 和非bert的不同之处
        if self.use_bert:
            
            # char_for_bert = lattice[:, :max_seq_len]
            char_for_bert = chars
            
            mask = seq_len_to_mask(seq_len).bool()
            char_for_bert = char_for_bert.masked_fill((~mask),self.vocabs['lattice'].padding_idx)
            bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            # bert_embed = self.bert_embedding_phrase(char_for_bert) # torch.Size([10, 141, 768])
            bert_embed = torch.cat([bert_embed,
                                    torch.zeros(size=[batch_size,max_char_lex_phrase-max_seq_len,bert_embed.size(-1)],
                                                device = bert_embed.device,
                                                requires_grad=False)],dim=-2)
            # print('bert_embed:{}'.format(bert_embed[:1, :3, -5:]))
            raw_embed_char = torch.cat([raw_embed_char, bert_embed],dim=-1) #执行之前，raw:[10, 211, 100]

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        # char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        char_mask = seq_len_to_mask(seq_len,max_len=max_char_lex_phrase).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]

        embed_lex = self.lex_proj(raw_embed)#raw_embed:[100,196,50] ,emb_lex:[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        # lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        lex_mask = (seq_len_to_mask(seq_len+lex_num+phrase_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)


        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

class Dual_Grained_Syntax_Aware_Transformer_SeqLabel_Online(nn.Module):
    def __init__(self, online, char_embed, words_embed, phrases_embed, bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos,use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',
                 four_pos_shared=True,four_pos_fusion=None,four_pos_fusion_shared=True,
                 bert_embedding=None,use_pytorch_dropout=False, domain_join=False, general_join=False,
                 residual = 'no', c_vm = False, t_vm = False, gate = False, cross = False, only_cross=False, topk=0):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化

        :param embed_dropout_pos: 如果是0，就直接在embed后dropout，是1就在embed变成hidden size之后再dropout，
        是2就在绝对位置加上之后dropout
        '''
        super().__init__()

        # TODO: Modified Mark: add domain_join, general_join params.
        self.domain_join = domain_join
        self.general_join = general_join

        self.c_vm = c_vm
        self.t_vm = t_vm

        self.cross = cross
        self.only_cross = only_cross

        self.use_bert = False
        if bert_embedding is not None:
            self.use_bert = True
            self.bert_embedding = bert_embedding

        self.use_pytorch_dropout = use_pytorch_dropout
        self.four_pos_fusion_shared = four_pos_fusion_shared
        self.mode = mode
        self.four_pos_shared = four_pos_shared
        self.abs_pos_fusion_func = abs_pos_fusion_func

        # self.lattice_embed = lattice_embed
        self.words_embed = words_embed


        # self.phrase_lattice_embed = phrase_lattice_embed
        self.char_embed = char_embed
        self.phrases_embed = phrases_embed

        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        # self.relative_position = relative_position
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        if self.use_rel_pos:
            assert four_pos_fusion is not None
        self.four_pos_fusion = four_pos_fusion
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init
        self.embed_dropout_pos = embed_dropout_pos


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)

        # if self.add_position:
        #     print('暂时只支持位置编码的concat模式')
        #     exit(1208)

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None

        if self.use_abs_pos:
            self.abs_pos_encode = Absolute_SE_Position_Embedding(self.abs_pos_fusion_func,
                                        self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                        pos_norm=self.pos_norm)

        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
            if self.four_pos_shared:
                self.pe_ss = self.pe
                self.pe_se = self.pe
                self.pe_es = self.pe
                self.pe_ee = self.pe
            else:
                self.pe_ss = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_se = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_es = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_ee = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
        else:
            self.pe = None
            self.pe_ss = None
            self.pe_se = None
            self.pe_es = None
            self.pe_ee = None






        # if self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        if self.use_bigram:
            self.bigram_size = self.bigram_embed.embedding.weight.size(1) # bigram.weight.shape:[107941, 50], size(1):50
            # lattice.weight.shape: [33357, 50], self.char_input_size:100, phrase.weight.shape:[39424, 50]
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)

        if self.use_bert:
            self.char_input_size+=self.bert_embedding._embed_size

        # self.lex_input_size = self.lattice_embed.embedding.weight.size(1) #50
        # lex size是word size
        self.lex_input_size = self.words_embed.embedding.weight.size(1) #50
        # phrase可能是pretrained，也可能是online的
        if online == 'static':
            self.phrase_input_size = self.phrases_embed.embedding.weight.size(1) #50
        else:
            self.phrase_input_size = self.phrases_embed.embed_size 
        

        if use_pytorch_dropout:
            self.embed_dropout = nn.Dropout(self.dropout['embed'])
            self.gaz_dropout = nn.Dropout(self.dropout['gaz'])
            self.output_dropout = nn.Dropout(self.dropout['output'])
        else:
            self.embed_dropout = MyDropout(self.dropout['embed'])
            self.gaz_dropout = MyDropout(self.dropout['gaz'])
            self.output_dropout = MyDropout(self.dropout['output'])


        self.char_proj = nn.Linear(self.char_input_size,self.hidden_size)
        self.lex_proj = nn.Linear(self.lex_input_size,self.hidden_size)
        self.phrase_proj = nn.Linear(self.phrase_input_size,self.hidden_size)

        self.residual = residual

        def get_transformer_encoder_by_vm_names(vm_names):
            self.use_two_vms = 'transformers' #这个参数后面好像没有用到
            self.use_vm = 1
            self.two_vms = 'concat'
            return Syntax_Aware_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                            relative_position=self.use_rel_pos,
                                            learnable_position=self.learnable_position,
                                            add_position=self.add_position,
                                            layer_preprocess_sequence=self.layer_preprocess_sequence,
                                            layer_postprocess_sequence=self.layer_postprocess_sequence,
                                            dropout=self.dropout,
                                            scaled=self.scaled,
                                            ff_size=self.ff_size,
                                            mode=self.mode,
                                            dvc=self.dvc,
                                            max_seq_len=self.max_seq_len,
                                            pe=self.pe,
                                            pe_ss=self.pe_ss,
                                            pe_se=self.pe_se,
                                            pe_es=self.pe_es,
                                            pe_ee=self.pe_ee,
                                            k_proj=self.k_proj,
                                            q_proj=self.q_proj,
                                            v_proj=self.v_proj,
                                            r_proj=self.r_proj,
                                            attn_ff=self.attn_ff,
                                            ff_activate=self.ff_activate,
                                            lattice=True,
                                            four_pos_fusion=self.four_pos_fusion,
                                            four_pos_fusion_shared=self.four_pos_fusion_shared,
                                            use_pytorch_dropout=self.use_pytorch_dropout,
                                            use_vm = self.use_vm,use_two_vms = self.use_two_vms,
                                            single_vm = vm_names, two_vms = self.two_vms,
                                            residual = residual)

        # fine-grained
        if not self.t_vm:
            self.encoder = self.get_encoder()
        else:
            self.encoder = get_transformer_encoder_by_vm_names(['t_vm'])

        # coarse-grained
        if not self.c_vm:
            self.phrase_encoder = self.get_encoder()
        else:
            self.phrase_encoder = get_transformer_encoder_by_vm_names(['c_vm'])

        # text
        self.text_encoder = self.get_encoder()

        # self.output = nn.Linear(self.hidden_size,self.label_size)
        # self.output = nn.Linear(self.hidden_size*2,self.label_size)

        # TODO: Modified Mark: add join.
        is_join = self.domain_join or self.general_join
        if is_join or gate:
            self.output = nn.Linear(self.hidden_size,self.label_size)
        # cross时，维度变大。
        else:
            # self.output = nn.Linear(self.hidden_size*2,self.label_size)
            self.output = nn.Linear(self.hidden_size*3,self.label_size)

        if cross or is_join :
            # TODO: Modified Mark: update encoder.
            if topk == 0:
                self.cross_encoder = self.get_cross_encoder()
            else:
                self.cross_encoder = self.get_cross_encoder_topk(topk)

        self.gate = gate
        if gate:
            # self.cat2gatess_1 = nn.Linear(self.hidden_size, self.hidden_size)
            # self.cat2gatess_2 = nn.Linear(self.hidden_size*2, self.hidden_size)
            # self.cat2gatess_3 = nn.Linear(self.hidden_size, self.hidden_size)
            self.cat2gatess_fi = nn.Linear(self.hidden_size*3, self.hidden_size) #
            self.cat2gatess_co = nn.Linear(self.hidden_size*3, self.hidden_size)
            self.cat2gatess_txt = nn.Linear(self.hidden_size*3, self.hidden_size)
            
            # bi-cross version
            if cross:
                self.cat2gatess_fi = nn.Linear(self.hidden_size*4, self.hidden_size) #
                self.cat2gatess_co = nn.Linear(self.hidden_size*4, self.hidden_size)
                self.cat2gatess_txt1 = nn.Linear(self.hidden_size*4, self.hidden_size)
                self.cat2gatess_txt2 = nn.Linear(self.hidden_size*4, self.hidden_size)

        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
        self.batch_num = 0

    def get_cross_encoder_topk(self,topk):
        # cross attention先不考虑rel position，因为有两套position，不好计算rel pos。
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                        relative_position=False,
                                        learnable_position=self.learnable_position,
                                        add_position=self.add_position,
                                        layer_preprocess_sequence=self.layer_preprocess_sequence,
                                        layer_postprocess_sequence=self.layer_postprocess_sequence,
                                        dropout=self.dropout,
                                        scaled=self.scaled,
                                        ff_size=self.ff_size,
                                        mode=self.mode,
                                        dvc=self.dvc,
                                        max_seq_len=self.max_seq_len,
                                        pe=self.pe,
                                        pe_ss=self.pe_ss,
                                        pe_se=self.pe_se,
                                        pe_es=self.pe_es,
                                        pe_ee=self.pe_ee,
                                        k_proj=self.k_proj,
                                        q_proj=self.q_proj,
                                        v_proj=self.v_proj,
                                        r_proj=self.r_proj,
                                        attn_ff=self.attn_ff,
                                        ff_activate=self.ff_activate,
                                        lattice=True,
                                        four_pos_fusion=self.four_pos_fusion,
                                        four_pos_fusion_shared=self.four_pos_fusion_shared,
                                        use_pytorch_dropout=self.use_pytorch_dropout,
                                        residual = self.residual,
                                        topk = topk)

    # TODO: Modified Mark: update encoder.
    def get_cross_encoder(self):
        # cross attention先不考虑rel position，因为有两套position，不好计算rel pos。
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=False,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)
    # lattice使用的也是cross-transformer，只不过传入的q,k,v是相同的。
    def get_encoder(self):
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)


    def forward(self, words, lattice, chars, phrases, phrase_lattice, bigrams, seq_len, lex_num, phrase_num, pos_s, pos_e, phrase_pos_s, phrase_pos_e,
                target, chars_target=None, c_vm = None, t_vm = None):
        # if self.training:
        #     self.batch_num+=1
        # if self.batch_num == 1000:
        #     exit()

        # print('lattice:')
        # print(lattice)
        
        # initial返回的结果中，只有emb不一样
        # dim2, dim3没什么用，只是调试用的
        # domain词典是online计算的，general词典不用online计算。
        # batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters(chars, lattice, bigrams, seq_len, lex_num, pos_s, pos_e)
        batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters_online(chars, words, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False)
        batch_size, max_seq_len, dim2, dim3, phrase_embedding = self.initial_parameters_online(chars, phrases, phrase_lattice, bigrams, seq_len, phrase_num, phrase_pos_s, phrase_pos_e, is_phrase=True)

        # 将0,1转换为false,true
        #vm自动由ndarray转换为tensor,同时维度增加了batch，[batch,seq_len,seq_len]
        #后面计算attention时需要增加1维，heads
        if self.c_vm:
            c_vm = (c_vm == 1).unsqueeze(1)
        if self.t_vm:
            t_vm = (t_vm == 1).unsqueeze(1)

        if not self.only_cross:

            if not self.t_vm:
                encoded = self.encoder(embedding,embedding,embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                                print_=(self.batch_num==327))
            else:
                # 注意，syntax-aware encoder和text encoder的forward参数不同
                encoded = self.encoder(embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                                print_=(self.batch_num==327),t_vm=t_vm)

            if not self.c_vm:
                # 在dust中，输入，也就是embeddings，是一样的。vm是不一样的。
                phrase_encoded = self.phrase_encoder(embedding,embedding,embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
                                    print_=(self.batch_num==327))
                # phrase_encoded = self.phrase_encoder(phrase_embedding,phrase_embedding,phrase_embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
                #                     print_=(self.batch_num==327))
            else:
                phrase_encoded = self.phrase_encoder(embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
                                    print_=(self.batch_num==327),c_vm=c_vm)

            text_encoded = self.text_encoder(embedding,embedding,embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                                print_=(self.batch_num==327))

            ### new version ###
            is_joint = self.domain_join or self.general_join
            # self.domain_join and self.general_join不能同时为true
            # assert self.domain_join and self.general_join

            if is_joint:
                # # domain_join：general给domain增强。
                # if self.domain_join:
                #     encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num=lex_num)    
                #     # if hasattr(self,'output_dropout'):
                #     #     encoded_cross = self.output_dropout(encoded_cross)
                #     encoded = encoded_cross[:,:max_seq_len,:]
                # elif self.general_join:
                #     encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,lex_num=phrase_num)    
                #     # if hasattr(self,'output_dropout'):
                #     #     encoded_cross = self.output_dropout(encoded_cross)
                #     encoded = encoded_cross[:,:max_seq_len,:]

                # syntax 为query, context为k,v
                if self.domain_join:
                    # encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num) # q, k, v
                    # phrase_encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,phrase_num)
                    
                    encoded_cross = self.cross_encoder(encoded,text_encoded,text_encoded,seq_len,lex_num) # q, k, v
                    phrase_encoded_cross = self.cross_encoder(phrase_encoded,text_encoded,text_encoded,seq_len,phrase_num)

                    if self.batch_num == 327:
                        print('{} encoded:{}'.format(self.batch_num,
                                                encoded[:2,dim2,:dim3]))

                    encoded = encoded_cross
                    phrase_encoded = phrase_encoded_cross

                # cascaded bi-cross 
                if self.general_join:
                    encoded_cross_e = self.cross_encoder(encoded,text_encoded,text_encoded,seq_len,lex_num) # q, k, v
                    encoded_cross_t = self.cross_encoder(text_encoded,encoded,encoded,seq_len,lex_num) # q, k, v
                    phrase_encoded_cross_p = self.cross_encoder(phrase_encoded,encoded_cross_t,encoded_cross_t,seq_len,phrase_num)
                    phrase_encoded_cross_t = self.cross_encoder(encoded_cross_t,phrase_encoded,phrase_encoded,seq_len,phrase_num)
                    # phrase_encoded_cross = self.cross_encoder(phrase_encoded,text_encoded,text_encoded,seq_len,phrase_num)

                    if self.batch_num == 327:
                        print('{} encoded:{}'.format(self.batch_num,
                                                encoded[:2,dim2,:dim3]))

                    encoded = encoded_cross_e
                    phrase_encoded = phrase_encoded_cross_p
                    text_encoded = phrase_encoded_cross_t

                if self.gate:
                    encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                    phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                    text_encoded = text_encoded[:,:max_seq_len,:]
                    # h1 = torch.tanh(self.cat2gatess_3(encoded))
                    # h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                    # g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                    # encoded = g1 * encoded + (1 - g1) * phrase_encoded
                    
                    g_fi = torch.sigmoid(self.cat2gatess_fi(torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)))
                    g_co = torch.sigmoid(self.cat2gatess_co(torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)))
                    g_txt = torch.sigmoid(self.cat2gatess_txt(torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)))
                    encoded = g_fi * encoded + g_co * phrase_encoded + g_txt * text_encoded
                else:
                    encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                    phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                    # encoded = torch.cat([encoded, phrase_encoded], dim=-1)
                    text_encoded = text_encoded[:,:max_seq_len,:]
                    encoded = torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)
            else:
                # if self.cross:
                #     # encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num) # q, k, v
                #     # phrase_encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,phrase_num)
                    
                #     encoded_cross = self.cross_encoder(text_encoded,encoded,encoded,seq_len,lex_num) # q, k, v
                #     phrase_encoded_cross = self.cross_encoder(text_encoded,phrase_encoded,phrase_encoded,seq_len,phrase_num)

                #     if self.batch_num == 327:
                #         print('{} encoded:{}'.format(self.batch_num,
                #                                 encoded[:2,dim2,:dim3]))

                #     encoded = encoded_cross
                #     phrase_encoded = phrase_encoded_cross

                # if self.gate:
                #     encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                #     phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                #     text_encoded = text_encoded[:,:max_seq_len,:]
                #     # h1 = torch.tanh(self.cat2gatess_3(encoded))
                #     # h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                #     # g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                #     # encoded = g1 * encoded + (1 - g1) * phrase_encoded
                    
                #     g_fi = torch.sigmoid(self.cat2gatess_fi(torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)))
                #     g_co = torch.sigmoid(self.cat2gatess_co(torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)))
                #     g_txt = torch.sigmoid(self.cat2gatess_txt(torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)))
                #     encoded = g_fi * encoded + g_co * phrase_encoded + g_txt * text_encoded
                # else:
                #     encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                #     phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                #     # encoded = torch.cat([encoded, phrase_encoded], dim=-1)
                #     text_encoded = text_encoded[:,:max_seq_len,:]
                #     encoded = torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)

                # bi-cross version
                if self.cross:
                    # encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num) # q, k, v
                    # phrase_encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,phrase_num)
                    
                    encoded_cross_t = self.cross_encoder(text_encoded,encoded,encoded,seq_len,lex_num) # q, k, v
                    encoded_cross_e = self.cross_encoder(encoded,text_encoded,text_encoded,seq_len,lex_num) # q, k, v
                    phrase_encoded_cross_t = self.cross_encoder(text_encoded,phrase_encoded,phrase_encoded,seq_len,phrase_num)
                    phrase_encoded_cross_p = self.cross_encoder(phrase_encoded,text_encoded,text_encoded,seq_len,phrase_num)

                    if self.batch_num == 327:
                        print('{} encoded:{}'.format(self.batch_num,
                                                encoded[:2,dim2,:dim3]))

                    encoded = encoded_cross_e
                    phrase_encoded = phrase_encoded_cross_p

                    text_encoded1 = encoded_cross_t
                    text_encoded2 = phrase_encoded_cross_t

                    if self.gate:
                        encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                        phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                        # text_encoded = text_encoded[:,:max_seq_len,:]
                        text_encoded1 = text_encoded1[:,:max_seq_len,:]
                        text_encoded2 = text_encoded2[:,:max_seq_len,:]
                        # h1 = torch.tanh(self.cat2gatess_3(encoded))
                        # h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                        # g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                        # encoded = g1 * encoded + (1 - g1) * phrase_encoded
                        
                        g_fi = torch.sigmoid(self.cat2gatess_fi(torch.cat([text_encoded1,text_encoded2, encoded, phrase_encoded], dim=-1)))
                        g_co = torch.sigmoid(self.cat2gatess_co(torch.cat([text_encoded1,text_encoded2, encoded, phrase_encoded], dim=-1)))
                        g_txt1 = torch.sigmoid(self.cat2gatess_txt1(torch.cat([text_encoded1,text_encoded2, encoded, phrase_encoded], dim=-1)))
                        g_txt2 = torch.sigmoid(self.cat2gatess_txt2(torch.cat([text_encoded1,text_encoded2, encoded, phrase_encoded], dim=-1)))
                        # encoded = g_fi * encoded + g_co * phrase_encoded + g_txt * text_encoded
                        encoded = g_fi * encoded + g_co * phrase_encoded + g_txt1 * text_encoded1 + g_txt2 * text_encoded2
                
                elif not self.cross and self.gate:
                    encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                    phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                    text_encoded = text_encoded[:,:max_seq_len,:]
                    # h1 = torch.tanh(self.cat2gatess_3(encoded))
                    # h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                    # g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                    # encoded = g1 * encoded + (1 - g1) * phrase_encoded
                    
                    g_fi = torch.sigmoid(self.cat2gatess_fi(torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)))
                    g_co = torch.sigmoid(self.cat2gatess_co(torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)))
                    g_txt = torch.sigmoid(self.cat2gatess_txt(torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)))
                    encoded = g_fi * encoded + g_co * phrase_encoded + g_txt * text_encoded

                else:
                    encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                    phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                    # encoded = torch.cat([encoded, phrase_encoded], dim=-1)
                    text_encoded = text_encoded[:,:max_seq_len,:]
                    encoded = torch.cat([text_encoded, encoded, phrase_encoded], dim=-1)
        # only inter-lattice transformer
        else:
            assert self.cross
            encoded_cross = self.cross_encoder(phrase_embedding, embedding,embedding,seq_len,lex_num) # q, k, v
            phrase_encoded_cross = self.cross_encoder(embedding,phrase_embedding,phrase_embedding,seq_len,phrase_num)

            if self.batch_num == 327:
                print('{} encoded:{}'.format(self.batch_num,
                                        encoded[:2,dim2,:dim3]))

            encoded = encoded_cross
            phrase_encoded = phrase_encoded_cross

            if self.gate:
                encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                h1 = torch.tanh(self.cat2gatess_3(encoded))
                h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                encoded = g1 * encoded + (1 - g1) * phrase_encoded
            else:
                encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                encoded = torch.cat([encoded, phrase_encoded], dim=-1)
            

        # 要在最后dropout。不要在前面dropout。
        if hasattr(self,'output_dropout'):
            # encoded_cross = self.output_dropout(encoded_cross)
            # phrase_encoded_cross = self.output_dropout(phrase_encoded_cross)
            encoded = self.output_dropout(encoded)

        pred = self.output(encoded)

        if self.batch_num == 327:
            print('{} pred:{}'.format(self.batch_num,
                                       pred[:2,dim2,:dim3]))

        # print('pred:{}'.format(pred[:,dim2,:dim3]))
        # exit()

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss

            if self.batch_num == 327:
                print('{} loss:{}'.format(self.batch_num,loss))
                exit()

            # exit()
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result

    def initial_parameters_online(self, chars, phrases, lattice,bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        # max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]
        max_seq_len = chars.size(1)

        # if not is_phrase:
        #     # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
        #     raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
        #     #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        # else:
        #     raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        # raw_embed是给lex用的，raw_embed_char是给char用的
        raw_embed_chars = self.char_embed(chars)
        if is_phrase:
            raw_embed_words = self.phrases_embed(phrases)
            raw_embed = torch.zeros(size=[batch_size,max_seq_len_and_lex_num,self.phrase_input_size]).to(raw_embed_chars)
        else:
            raw_embed_words = self.words_embed(phrases)
            raw_embed = torch.zeros(size=[batch_size,max_seq_len_and_lex_num,self.lex_input_size]).to(raw_embed_chars)

        
        
        char_size = self.char_embed.embedding.weight.size(1)
        # if char_size != self.lex_input_size:
        # 假设lex可能大约char的维度。需要对char补0来对齐维度。
        # 如果char的维度大于lex的维度，则需要对lex补0来对齐维度。
        assert char_size <= self.lex_input_size
        # 可能char：50维，lex：200维。
        # 为了和lex进行concat，用0来增加了维度。
        # 但这部分维度其实不需要，所以单独做raw_embed_chars4bigram，用来char+bigram+bert。
        # raw_embed_chars = self.char_proj2lex(raw_embed_chars)
        if is_phrase:
            raw_embed_chars4lex = torch.cat([raw_embed_chars,torch.zeros(size=[batch_size,max_seq_len,self.phrase_input_size-char_size]).to(raw_embed_chars)],dim=-1)
        else:
            raw_embed_chars4lex = torch.cat([raw_embed_chars,torch.zeros(size=[batch_size,max_seq_len,self.lex_input_size-char_size]).to(raw_embed_chars)],dim=-1)
        
        # char和bigram维度一样
        raw_embed_chars4bigram = torch.cat([raw_embed_chars,
                                    torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                        char_size]).to(raw_embed_chars)],dim=1)

        for ind,(i,j) in enumerate(zip(seq_len,lex_num)):
            # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
            # lex_num是list，是每个instance匹配到词的个数。
            # 最后加pad，确保和lattice的维度一致。
            chars_words = torch.cat([raw_embed_chars4lex[ind][:i],raw_embed_words[ind][:j]],dim=0) #[125, 50],[54, 50]->[179,50]
            if is_phrase:
                pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.phrase_input_size]).to(raw_embed_chars) #[10,50]
            else:
                pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.lex_input_size]).to(raw_embed_chars) #[10,50]
            chars_words_pads = torch.cat([chars_words,pads_temp],dim=0)
            raw_embed[ind] = chars_words_pads

        # for ind,(i,j) in enumerate(zip(seq_len,lex_num)):
        #     # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
        #     # lex_num是list，是每个instance匹配到词的个数。
        #     # 最后加pad，确保和lattice的维度一致。
        #     chars_words = torch.cat([raw_embed_chars[ind][:i],raw_embed_words[ind][:j]],dim=0) #[125, 50],[54, 50]->[179,50]
        #     pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.lex_input_size]).to(raw_embed_chars) #[10,50]
        #     chars_words_pads = torch.cat([chars_words,pads_temp],dim=0)
        #     raw_embed[ind] = chars_words_pads

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            # raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
            raw_embed_char = torch.cat([raw_embed_chars4bigram, bigrams_embed],dim=-1) # raw_embed_char:[10,102,100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))

        if self.use_bert:
            bert_pad_length = lattice.size(1)-max_seq_len # lattice.size(1): 211; max_seq_len: 141; pad_length: 70
            
            # char_for_bert = lattice[:, :max_seq_len]
            char_for_bert = chars

            mask = seq_len_to_mask(seq_len).bool()
            char_for_bert = char_for_bert.masked_fill((~mask),self.vocabs['lattice'].padding_idx)
            
            # 老版本，需要2个bert，为2个bert都要设置不同的学习率。
            # if not is_phrase:
            #     bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            # else:
            #     bert_embed = self.bert_embedding_phrase(char_for_bert) # torch.Size([10, 141, 768])

            bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            
            bert_embed = torch.cat([bert_embed,
                                    torch.zeros(size=[batch_size,bert_pad_length,bert_embed.size(-1)],
                                                device = bert_embed.device,
                                                requires_grad=False)],dim=-2)
            # print('bert_embed:{}'.format(bert_embed[:1, :3, -5:]))
            raw_embed_char = torch.cat([raw_embed_char, bert_embed],dim=-1) #执行之前，raw:[10, 211, 100]

        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]
        
        if is_phrase:
            embed_lex = self.phrase_proj(raw_embed)#[10, 196, 128]
        else:
            embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

    def initial_parameters(self, chars, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]

        if not is_phrase:
            # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
            raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
            #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        else:
            raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2

        if self.use_bert:
            bert_pad_length = lattice.size(1)-max_seq_len # lattice.size(1): 211; max_seq_len: 141; pad_length: 70
            
            # char_for_bert = lattice[:, :max_seq_len]
            char_for_bert = chars

            mask = seq_len_to_mask(seq_len).bool()
            char_for_bert = char_for_bert.masked_fill((~mask),self.vocabs['lattice'].padding_idx)
            
            # 老版本，需要2个bert，为2个bert都要设置不同的学习率。
            # if not is_phrase:
            #     bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            # else:
            #     bert_embed = self.bert_embedding_phrase(char_for_bert) # torch.Size([10, 141, 768])

            bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            
            bert_embed = torch.cat([bert_embed,
                                    torch.zeros(size=[batch_size,bert_pad_length,bert_embed.size(-1)],
                                                device = bert_embed.device,
                                                requires_grad=False)],dim=-2)
            # print('bert_embed:{}'.format(bert_embed[:1, :3, -5:]))
            raw_embed_char = torch.cat([raw_embed_char, bert_embed],dim=-1) #执行之前，raw:[10, 211, 100]

        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]

        embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

# # 将phrase_lattice_embed用chars,phrases替换
class Cross_Lattice_Transformer_SeqLabel_Online(nn.Module):
    def __init__(self, online, char_embed, words_embed, phrases_embed, bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos,use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',
                 four_pos_shared=True,four_pos_fusion=None,four_pos_fusion_shared=True,
                 bert_embedding=None,use_pytorch_dropout=False,
                 residual = 'no',domain_join = False, general_join = False, gate = False, cross = False, only_cross=False, topk=0):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化

        :param embed_dropout_pos: 如果是0，就直接在embed后dropout，是1就在embed变成hidden size之后再dropout，
        是2就在绝对位置加上之后dropout
        '''
        super().__init__()

        # TODO: Modified Mark: add domain_join, general_join params.
        self.domain_join = domain_join
        self.general_join = general_join

        self.cross = cross
        self.only_cross = only_cross

        self.use_bert = False
        if bert_embedding is not None:
            self.use_bert = True
            self.bert_embedding = bert_embedding

        self.use_pytorch_dropout = use_pytorch_dropout
        self.four_pos_fusion_shared = four_pos_fusion_shared
        self.mode = mode
        self.four_pos_shared = four_pos_shared
        self.abs_pos_fusion_func = abs_pos_fusion_func

        # self.lattice_embed = lattice_embed
        self.words_embed = words_embed


        # self.phrase_lattice_embed = phrase_lattice_embed
        self.char_embed = char_embed
        self.phrases_embed = phrases_embed

        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        # self.relative_position = relative_position
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        if self.use_rel_pos:
            assert four_pos_fusion is not None
        self.four_pos_fusion = four_pos_fusion
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init
        self.embed_dropout_pos = embed_dropout_pos


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)

        # if self.add_position:
        #     print('暂时只支持位置编码的concat模式')
        #     exit(1208)

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None

        if self.use_abs_pos:
            self.abs_pos_encode = Absolute_SE_Position_Embedding(self.abs_pos_fusion_func,
                                        self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                        pos_norm=self.pos_norm)

        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
            if self.four_pos_shared:
                self.pe_ss = self.pe
                self.pe_se = self.pe
                self.pe_es = self.pe
                self.pe_ee = self.pe
            else:
                self.pe_ss = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_se = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_es = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_ee = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
        else:
            self.pe = None
            self.pe_ss = None
            self.pe_se = None
            self.pe_es = None
            self.pe_ee = None






        # if self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        if self.use_bigram:
            self.bigram_size = self.bigram_embed.embedding.weight.size(1) # bigram.weight.shape:[107941, 50], size(1):50
            # lattice.weight.shape: [33357, 50], self.char_input_size:100, phrase.weight.shape:[39424, 50]
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)

        if self.use_bert:
            self.char_input_size+=self.bert_embedding._embed_size

        # self.lex_input_size = self.lattice_embed.embedding.weight.size(1) #50
        # lex size是word size
        self.lex_input_size = self.words_embed.embedding.weight.size(1) #50
        # phrase可能是pretrained，也可能是online的
        if online == 'static':
            self.phrase_input_size = self.phrases_embed.embedding.weight.size(1) #50
        else:
            self.phrase_input_size = self.phrases_embed.embed_size 
        

        if use_pytorch_dropout:
            self.embed_dropout = nn.Dropout(self.dropout['embed'])
            self.gaz_dropout = nn.Dropout(self.dropout['gaz'])
            self.output_dropout = nn.Dropout(self.dropout['output'])
        else:
            self.embed_dropout = MyDropout(self.dropout['embed'])
            self.gaz_dropout = MyDropout(self.dropout['gaz'])
            self.output_dropout = MyDropout(self.dropout['output'])


        self.char_proj = nn.Linear(self.char_input_size,self.hidden_size)
        self.lex_proj = nn.Linear(self.lex_input_size,self.hidden_size)
        self.phrase_proj = nn.Linear(self.phrase_input_size,self.hidden_size)

        self.residual = residual

        self.encoder = self.get_encoder()
        self.phrase_encoder = self.get_encoder()

        # self.output = nn.Linear(self.hidden_size,self.label_size)
        # self.output = nn.Linear(self.hidden_size*2,self.label_size)

        # TODO: Modified Mark: add join.
        is_join = self.domain_join or self.general_join
        if is_join or gate:
            self.output = nn.Linear(self.hidden_size,self.label_size)
        # cross时，维度变大。
        else:
            self.output = nn.Linear(self.hidden_size*2,self.label_size)

        if cross or is_join :
            # TODO: Modified Mark: update encoder.
            if topk == 0:
                self.cross_encoder = self.get_cross_encoder()
            else:
                self.cross_encoder = self.get_cross_encoder_topk(topk)

        self.gate = gate
        if gate:
            self.cat2gatess_1 = nn.Linear(self.hidden_size, self.hidden_size)
            self.cat2gatess_2 = nn.Linear(self.hidden_size*2, self.hidden_size)
            self.cat2gatess_3 = nn.Linear(self.hidden_size, self.hidden_size)

        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
        self.batch_num = 0
    
    def get_cross_encoder_topk(self,topk):
            # cross attention先不考虑rel position，因为有两套position，不好计算rel pos。
            return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                            relative_position=False,
                                            learnable_position=self.learnable_position,
                                            add_position=self.add_position,
                                            layer_preprocess_sequence=self.layer_preprocess_sequence,
                                            layer_postprocess_sequence=self.layer_postprocess_sequence,
                                            dropout=self.dropout,
                                            scaled=self.scaled,
                                            ff_size=self.ff_size,
                                            mode=self.mode,
                                            dvc=self.dvc,
                                            max_seq_len=self.max_seq_len,
                                            pe=self.pe,
                                            pe_ss=self.pe_ss,
                                            pe_se=self.pe_se,
                                            pe_es=self.pe_es,
                                            pe_ee=self.pe_ee,
                                            k_proj=self.k_proj,
                                            q_proj=self.q_proj,
                                            v_proj=self.v_proj,
                                            r_proj=self.r_proj,
                                            attn_ff=self.attn_ff,
                                            ff_activate=self.ff_activate,
                                            lattice=True,
                                            four_pos_fusion=self.four_pos_fusion,
                                            four_pos_fusion_shared=self.four_pos_fusion_shared,
                                            use_pytorch_dropout=self.use_pytorch_dropout,
                                            residual = self.residual,
                                            topk = topk)

    # TODO: Modified Mark: update encoder.
    def get_cross_encoder(self):
        # cross attention先不考虑rel position，因为有两套position，不好计算rel pos。
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=False,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)
    # lattice使用的也是cross-transformer，只不过传入的q,k,v是相同的，且传入rel pos。
    def get_encoder(self):
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)


    def forward(self, words, lattice, chars, phrases, phrase_lattice, bigrams, seq_len, lex_num, phrase_num, pos_s, pos_e, phrase_pos_s, phrase_pos_e,
                target, chars_target=None):
        # if self.training:
        #     self.batch_num+=1
        # if self.batch_num == 1000:
        #     exit()

        # print('lattice:')
        # print(lattice)
        
        # initial返回的结果中，只有emb不一样
        # dim2, dim3没什么用，只是调试用的
        # domain词典是online计算的，general词典不用online计算。
        # batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters(chars, lattice, bigrams, seq_len, lex_num, pos_s, pos_e)
        batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters_online(chars, words, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False)
        batch_size, max_seq_len, dim2, dim3, phrase_embedding = self.initial_parameters_online(chars, phrases, phrase_lattice, bigrams, seq_len, phrase_num, phrase_pos_s, phrase_pos_e, is_phrase=True)

        if not self.only_cross:
            encoded = self.encoder(embedding,embedding,embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                                print_=(self.batch_num==327))

            phrase_encoded = self.phrase_encoder(phrase_embedding,phrase_embedding,phrase_embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
                                print_=(self.batch_num==327))

            ### new version ###
            is_joint = self.domain_join or self.general_join
            # self.domain_join and self.general_join不能同时为true
            # assert self.domain_join and self.general_join

            if is_joint:
                # domain_join：general给domain增强。
                if self.domain_join:
                    encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num=lex_num)    
                    # if hasattr(self,'output_dropout'):
                    #     encoded_cross = self.output_dropout(encoded_cross)
                    encoded = encoded_cross[:,:max_seq_len,:]
                elif self.general_join:
                    encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,lex_num=phrase_num)    
                    # if hasattr(self,'output_dropout'):
                    #     encoded_cross = self.output_dropout(encoded_cross)
                    encoded = encoded_cross[:,:max_seq_len,:]
            else:
                if self.cross:
                    encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num) # q, k, v
                    phrase_encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,phrase_num)
                    

                    if self.batch_num == 327:
                        print('{} encoded:{}'.format(self.batch_num,
                                                encoded[:2,dim2,:dim3]))

                    encoded = encoded_cross
                    phrase_encoded = phrase_encoded_cross

                if self.gate:
                    encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                    phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                    h1 = torch.tanh(self.cat2gatess_3(encoded))
                    h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                    g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                    encoded = g1 * encoded + (1 - g1) * phrase_encoded
                else:
                    encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                    phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                    encoded = torch.cat([encoded, phrase_encoded], dim=-1)
        # only inter-lattice transformer
        else:
            assert self.cross
            encoded_cross = self.cross_encoder(phrase_embedding, embedding,embedding,seq_len,lex_num) # q, k, v
            phrase_encoded_cross = self.cross_encoder(embedding,phrase_embedding,phrase_embedding,seq_len,phrase_num)

            if self.batch_num == 327:
                print('{} encoded:{}'.format(self.batch_num,
                                        encoded[:2,dim2,:dim3]))

            encoded = encoded_cross
            phrase_encoded = phrase_encoded_cross

            if self.gate:
                encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                h1 = torch.tanh(self.cat2gatess_3(encoded))
                h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                encoded = g1 * encoded + (1 - g1) * phrase_encoded
            else:
                encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                encoded = torch.cat([encoded, phrase_encoded], dim=-1)
            

        # 要在最后dropout。不要在前面dropout。
        if hasattr(self,'output_dropout'):
            # encoded_cross = self.output_dropout(encoded_cross)
            # phrase_encoded_cross = self.output_dropout(phrase_encoded_cross)
            encoded = self.output_dropout(encoded)

        pred = self.output(encoded)

        if self.batch_num == 327:
            print('{} pred:{}'.format(self.batch_num,
                                       pred[:2,dim2,:dim3]))

        # print('pred:{}'.format(pred[:,dim2,:dim3]))
        # exit()

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss

            if self.batch_num == 327:
                print('{} loss:{}'.format(self.batch_num,loss))
                exit()

            # exit()
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result

    def initial_parameters_online(self, chars, phrases, lattice,bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        # max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]
        max_seq_len = chars.size(1)

        # if not is_phrase:
        #     # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
        #     raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
        #     #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        # else:
        #     raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        # raw_embed是给lex用的，raw_embed_char是给char用的
        raw_embed_chars = self.char_embed(chars)
        if is_phrase:
            raw_embed_words = self.phrases_embed(phrases)
            raw_embed = torch.zeros(size=[batch_size,max_seq_len_and_lex_num,self.phrase_input_size]).to(raw_embed_chars)
        else:
            raw_embed_words = self.words_embed(phrases)
            raw_embed = torch.zeros(size=[batch_size,max_seq_len_and_lex_num,self.lex_input_size]).to(raw_embed_chars)

        
        
        char_size = self.char_embed.embedding.weight.size(1)
        # if char_size != self.lex_input_size:
        # 假设lex可能大约char的维度。需要对char补0来对齐维度。
        # 如果char的维度大于lex的维度，则需要对lex补0来对齐维度。
        assert char_size <= self.lex_input_size
        # 可能char：50维，lex：200维。
        # 为了和lex进行concat，用0来增加了维度。
        # 但这部分维度其实不需要，所以单独做raw_embed_chars4bigram，用来char+bigram+bert。
        # raw_embed_chars = self.char_proj2lex(raw_embed_chars)
        if is_phrase:
            raw_embed_chars4lex = torch.cat([raw_embed_chars,torch.zeros(size=[batch_size,max_seq_len,self.phrase_input_size-char_size]).to(raw_embed_chars)],dim=-1)
        else:
            raw_embed_chars4lex = torch.cat([raw_embed_chars,torch.zeros(size=[batch_size,max_seq_len,self.lex_input_size-char_size]).to(raw_embed_chars)],dim=-1)
        
        # char和bigram维度一样
        raw_embed_chars4bigram = torch.cat([raw_embed_chars,
                                    torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                        char_size]).to(raw_embed_chars)],dim=1)

        for ind,(i,j) in enumerate(zip(seq_len,lex_num)):
            # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
            # lex_num是list，是每个instance匹配到词的个数。
            # 最后加pad，确保和lattice的维度一致。
            chars_words = torch.cat([raw_embed_chars4lex[ind][:i],raw_embed_words[ind][:j]],dim=0) #[125, 50],[54, 50]->[179,50]
            if is_phrase:
                pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.phrase_input_size]).to(raw_embed_chars) #[10,50]
            else:
                pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.lex_input_size]).to(raw_embed_chars) #[10,50]
            chars_words_pads = torch.cat([chars_words,pads_temp],dim=0)
            raw_embed[ind] = chars_words_pads

        # for ind,(i,j) in enumerate(zip(seq_len,lex_num)):
        #     # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
        #     # lex_num是list，是每个instance匹配到词的个数。
        #     # 最后加pad，确保和lattice的维度一致。
        #     chars_words = torch.cat([raw_embed_chars[ind][:i],raw_embed_words[ind][:j]],dim=0) #[125, 50],[54, 50]->[179,50]
        #     pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.lex_input_size]).to(raw_embed_chars) #[10,50]
        #     chars_words_pads = torch.cat([chars_words,pads_temp],dim=0)
        #     raw_embed[ind] = chars_words_pads

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            # raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
            raw_embed_char = torch.cat([raw_embed_chars4bigram, bigrams_embed],dim=-1) # raw_embed_char:[10,102,100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))

        if self.use_bert:
            bert_pad_length = lattice.size(1)-max_seq_len # lattice.size(1): 211; max_seq_len: 141; pad_length: 70
            
            # char_for_bert = lattice[:, :max_seq_len]
            char_for_bert = chars

            mask = seq_len_to_mask(seq_len).bool()
            char_for_bert = char_for_bert.masked_fill((~mask),self.vocabs['lattice'].padding_idx)
            
            # 老版本，需要2个bert，为2个bert都要设置不同的学习率。
            # if not is_phrase:
            #     bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            # else:
            #     bert_embed = self.bert_embedding_phrase(char_for_bert) # torch.Size([10, 141, 768])

            bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            
            bert_embed = torch.cat([bert_embed,
                                    torch.zeros(size=[batch_size,bert_pad_length,bert_embed.size(-1)],
                                                device = bert_embed.device,
                                                requires_grad=False)],dim=-2)
            # print('bert_embed:{}'.format(bert_embed[:1, :3, -5:]))
            raw_embed_char = torch.cat([raw_embed_char, bert_embed],dim=-1) #执行之前，raw:[10, 211, 100]

        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]
        
        if is_phrase:
            embed_lex = self.phrase_proj(raw_embed)#[10, 196, 128]
        else:
            embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

    def initial_parameters(self, chars, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]

        if not is_phrase:
            # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
            raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
            #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        else:
            raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2

        if self.use_bert:
            bert_pad_length = lattice.size(1)-max_seq_len # lattice.size(1): 211; max_seq_len: 141; pad_length: 70
            
            # char_for_bert = lattice[:, :max_seq_len]
            char_for_bert = chars

            mask = seq_len_to_mask(seq_len).bool()
            char_for_bert = char_for_bert.masked_fill((~mask),self.vocabs['lattice'].padding_idx)
            
            # 老版本，需要2个bert，为2个bert都要设置不同的学习率。
            # if not is_phrase:
            #     bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            # else:
            #     bert_embed = self.bert_embedding_phrase(char_for_bert) # torch.Size([10, 141, 768])

            bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            
            bert_embed = torch.cat([bert_embed,
                                    torch.zeros(size=[batch_size,bert_pad_length,bert_embed.size(-1)],
                                                device = bert_embed.device,
                                                requires_grad=False)],dim=-2)
            # print('bert_embed:{}'.format(bert_embed[:1, :3, -5:]))
            raw_embed_char = torch.cat([raw_embed_char, bert_embed],dim=-1) #执行之前，raw:[10, 211, 100]

        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]

        embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

class Cross_Lattice_Transformer_SeqLabel_Online_Cross_Position(nn.Module):
    def __init__(self, online, char_embed, words_embed, phrases_embed, bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos,use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',
                 four_pos_shared=True,four_pos_fusion=None,four_pos_fusion_shared=True,
                 bert_embedding=None,use_pytorch_dropout=False,
                 residual = 'no',domain_join = False, general_join = False, gate = False, cross = False, only_cross=False, cross_position = False):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化

        :param embed_dropout_pos: 如果是0，就直接在embed后dropout，是1就在embed变成hidden size之后再dropout，
        是2就在绝对位置加上之后dropout
        '''
        super().__init__()

        # TODO: Modified Mark: add domain_join, general_join params.
        self.domain_join = domain_join
        self.general_join = general_join

        self.cross = cross
        self.only_cross = only_cross
        self.cross_position = cross_position

        self.use_bert = False
        if bert_embedding is not None:
            self.use_bert = True
            self.bert_embedding = bert_embedding

        self.use_pytorch_dropout = use_pytorch_dropout
        self.four_pos_fusion_shared = four_pos_fusion_shared
        self.mode = mode
        self.four_pos_shared = four_pos_shared
        self.abs_pos_fusion_func = abs_pos_fusion_func

        # self.lattice_embed = lattice_embed
        self.words_embed = words_embed


        # self.phrase_lattice_embed = phrase_lattice_embed
        self.char_embed = char_embed
        self.phrases_embed = phrases_embed

        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        # self.relative_position = relative_position
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        if self.use_rel_pos:
            assert four_pos_fusion is not None
        self.four_pos_fusion = four_pos_fusion
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init
        self.embed_dropout_pos = embed_dropout_pos


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)

        # if self.add_position:
        #     print('暂时只支持位置编码的concat模式')
        #     exit(1208)

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None

        if self.use_abs_pos:
            self.abs_pos_encode = Absolute_SE_Position_Embedding(self.abs_pos_fusion_func,
                                        self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                        pos_norm=self.pos_norm)

        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
            if self.four_pos_shared:
                self.pe_ss = self.pe
                self.pe_se = self.pe
                self.pe_es = self.pe
                self.pe_ee = self.pe
            else:
                self.pe_ss = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_se = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_es = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_ee = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
        else:
            self.pe = None
            self.pe_ss = None
            self.pe_se = None
            self.pe_es = None
            self.pe_ee = None






        # if self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        if self.use_bigram:
            self.bigram_size = self.bigram_embed.embedding.weight.size(1) # bigram.weight.shape:[107941, 50], size(1):50
            # lattice.weight.shape: [33357, 50], self.char_input_size:100, phrase.weight.shape:[39424, 50]
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)

        if self.use_bert:
            self.char_input_size+=self.bert_embedding._embed_size

        # self.lex_input_size = self.lattice_embed.embedding.weight.size(1) #50
        # lex size是word size
        self.lex_input_size = self.words_embed.embedding.weight.size(1) #50
        # phrase可能是pretrained，也可能是online的
        if online == 'static':
            self.phrase_input_size = self.phrases_embed.embedding.weight.size(1) #50
        else:
            self.phrase_input_size = self.phrases_embed.embed_size 
        

        if use_pytorch_dropout:
            self.embed_dropout = nn.Dropout(self.dropout['embed'])
            self.gaz_dropout = nn.Dropout(self.dropout['gaz'])
            self.output_dropout = nn.Dropout(self.dropout['output'])
        else:
            self.embed_dropout = MyDropout(self.dropout['embed'])
            self.gaz_dropout = MyDropout(self.dropout['gaz'])
            self.output_dropout = MyDropout(self.dropout['output'])


        self.char_proj = nn.Linear(self.char_input_size,self.hidden_size)
        self.lex_proj = nn.Linear(self.lex_input_size,self.hidden_size)
        self.phrase_proj = nn.Linear(self.phrase_input_size,self.hidden_size)

        self.residual = residual

        self.encoder = self.get_encoder()
        self.phrase_encoder = self.get_encoder()

        # self.output = nn.Linear(self.hidden_size,self.label_size)
        # self.output = nn.Linear(self.hidden_size*2,self.label_size)

        # TODO: Modified Mark: add join.
        is_join = self.domain_join or self.general_join
        if is_join or gate:
            self.output = nn.Linear(self.hidden_size,self.label_size)
        # cross时，维度变大。
        else:
            self.output = nn.Linear(self.hidden_size*2,self.label_size)

        if cross or is_join :
            # TODO: Modified Mark: update encoder.
            if not cross_position:
                self.cross_encoder = self.get_cross_encoder()
            else:
                self.cross_encoder = self.get_cross_encoder_cross_position()

        self.gate = gate
        if gate:
            self.cat2gatess_1 = nn.Linear(self.hidden_size, self.hidden_size)
            self.cat2gatess_2 = nn.Linear(self.hidden_size*2, self.hidden_size)
            self.cat2gatess_3 = nn.Linear(self.hidden_size, self.hidden_size)

        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
        self.batch_num = 0
    
    # TODO: Modified Mark: update encoder.
    def get_cross_encoder(self):
        # cross attention先不考虑rel position，因为有两套position，不好计算rel pos。
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=False,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)

    def get_cross_encoder_cross_position(self):
        return Cross_Transformer_Encoder_Cross_Position(self.hidden_size,self.num_heads//2,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)

    def get_encoder(self):
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)


    def forward(self, words, lattice, chars, phrases, phrase_lattice, bigrams, seq_len, lex_num, phrase_num, pos_s, pos_e, phrase_pos_s, phrase_pos_e,
                target, chars_target=None):
        # if self.training:
        #     self.batch_num+=1
        # if self.batch_num == 1000:
        #     exit()

        # print('lattice:')
        # print(lattice)
        
        # initial返回的结果中，只有emb不一样
        # dim2, dim3没什么用，只是调试用的
        # domain词典是online计算的，general词典不用online计算。
        # batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters(chars, lattice, bigrams, seq_len, lex_num, pos_s, pos_e)
        batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters_online(chars, words, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False)
        batch_size, max_seq_len, dim2, dim3, phrase_embedding = self.initial_parameters_online(chars, phrases, phrase_lattice, bigrams, seq_len, phrase_num, phrase_pos_s, phrase_pos_e, is_phrase=True)

        if not self.only_cross:
            encoded = self.encoder(embedding,embedding,embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                                print_=(self.batch_num==327))

            phrase_encoded = self.phrase_encoder(phrase_embedding,phrase_embedding,phrase_embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
                                print_=(self.batch_num==327))

            ### new version ###
            is_joint = self.domain_join or self.general_join
            # self.domain_join and self.general_join不能同时为true
            # assert self.domain_join and self.general_join

            if is_joint:
                # domain_join：general给domain增强。
                if self.domain_join:
                    encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num=lex_num)    
                    # if hasattr(self,'output_dropout'):
                    #     encoded_cross = self.output_dropout(encoded_cross)
                    encoded = encoded_cross[:,:max_seq_len,:]
                elif self.general_join:
                    encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,lex_num=phrase_num)    
                    # if hasattr(self,'output_dropout'):
                    #     encoded_cross = self.output_dropout(encoded_cross)
                    encoded = encoded_cross[:,:max_seq_len,:]
            else:
                if self.cross:
                    if not self.cross_position:
                        encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num) # q, k, v
                        phrase_encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,phrase_num)
                    else:
                        # query的pos作为i，k的pos作为j。
                        encoded_cross = self.cross_encoder(phrase_embedding, embedding,embedding,seq_len,lex_num,pos_s_i=phrase_pos_s,pos_s_j=pos_s,pos_e_i=phrase_pos_e,pos_e_j=pos_e) # q, k, v
                        phrase_encoded_cross = self.cross_encoder(embedding,phrase_embedding,phrase_embedding,seq_len,phrase_num,pos_s_i=pos_s,pos_s_j=phrase_pos_s,pos_e_i=pos_e,pos_e_j=phrase_pos_e)

                    if self.batch_num == 327:
                        print('{} encoded:{}'.format(self.batch_num,
                                                encoded[:2,dim2,:dim3]))

                    encoded = encoded_cross
                    phrase_encoded = phrase_encoded_cross

                if self.gate:
                    encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                    phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                    h1 = torch.tanh(self.cat2gatess_3(encoded))
                    h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                    g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                    encoded = g1 * encoded + (1 - g1) * phrase_encoded
                else:
                    encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                    phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                    encoded = torch.cat([encoded, phrase_encoded], dim=-1)
        # only inter-lattice transformer
        else:
            assert self.cross
            
            if not self.cross_position:
                encoded_cross = self.cross_encoder(phrase_embedding, embedding,embedding,seq_len,lex_num) # q, k, v
                phrase_encoded_cross = self.cross_encoder(embedding,phrase_embedding,phrase_embedding,seq_len,phrase_num)
            else:
                # query的pos作为i，k的pos作为j。
                encoded_cross = self.cross_encoder(phrase_embedding, embedding,embedding,seq_len,lex_num,pos_s_i=phrase_pos_s,pos_s_j=pos_s,pos_e_i=phrase_pos_e,pos_e_j=pos_e) # q, k, v
                phrase_encoded_cross = self.cross_encoder(embedding,phrase_embedding,phrase_embedding,seq_len,phrase_num,pos_s_i=pos_s,pos_s_j=phrase_pos_s,pos_e_i=pos_e,pos_e_j=phrase_pos_e)

            # encoded = self.encoder(embedding,embedding,embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
            #                     )
            # phrase_encoded = self.phrase_encoder(phrase_embedding,phrase_embedding,phrase_embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
            #                     )

            if self.batch_num == 327:
                print('{} encoded:{}'.format(self.batch_num,
                                        encoded[:2,dim2,:dim3]))

            encoded = encoded_cross
            phrase_encoded = phrase_encoded_cross

            if self.gate:
                encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                h1 = torch.tanh(self.cat2gatess_3(encoded))
                h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                encoded = g1 * encoded + (1 - g1) * phrase_encoded
            else:
                encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                encoded = torch.cat([encoded, phrase_encoded], dim=-1)
            

        # 要在最后dropout。不要在前面dropout。
        if hasattr(self,'output_dropout'):
            # encoded_cross = self.output_dropout(encoded_cross)
            # phrase_encoded_cross = self.output_dropout(phrase_encoded_cross)
            encoded = self.output_dropout(encoded)

        pred = self.output(encoded)

        if self.batch_num == 327:
            print('{} pred:{}'.format(self.batch_num,
                                       pred[:2,dim2,:dim3]))

        # print('pred:{}'.format(pred[:,dim2,:dim3]))
        # exit()

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss

            if self.batch_num == 327:
                print('{} loss:{}'.format(self.batch_num,loss))
                exit()

            # exit()
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result

    def initial_parameters_online(self, chars, phrases, lattice,bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        # max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]
        max_seq_len = chars.size(1)

        # if not is_phrase:
        #     # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
        #     raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
        #     #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        # else:
        #     raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        # raw_embed是给lex用的，raw_embed_char是给char用的
        raw_embed_chars = self.char_embed(chars)
        if is_phrase:
            raw_embed_words = self.phrases_embed(phrases)
            raw_embed = torch.zeros(size=[batch_size,max_seq_len_and_lex_num,self.phrase_input_size]).to(raw_embed_chars)
        else:
            raw_embed_words = self.words_embed(phrases)
            raw_embed = torch.zeros(size=[batch_size,max_seq_len_and_lex_num,self.lex_input_size]).to(raw_embed_chars)

        
        
        char_size = self.char_embed.embedding.weight.size(1)
        # if char_size != self.lex_input_size:
        # 假设lex可能大约char的维度。需要对char补0来对齐维度。
        # 如果char的维度大于lex的维度，则需要对lex补0来对齐维度。
        assert char_size <= self.lex_input_size
        # 可能char：50维，lex：200维。
        # 为了和lex进行concat，用0来增加了维度。
        # 但这部分维度其实不需要，所以单独做raw_embed_chars4bigram，用来char+bigram+bert。
        # raw_embed_chars = self.char_proj2lex(raw_embed_chars)
        if is_phrase:
            raw_embed_chars4lex = torch.cat([raw_embed_chars,torch.zeros(size=[batch_size,max_seq_len,self.phrase_input_size-char_size]).to(raw_embed_chars)],dim=-1)
        else:
            raw_embed_chars4lex = torch.cat([raw_embed_chars,torch.zeros(size=[batch_size,max_seq_len,self.lex_input_size-char_size]).to(raw_embed_chars)],dim=-1)
        
        # char和bigram维度一样
        raw_embed_chars4bigram = torch.cat([raw_embed_chars,
                                    torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                        char_size]).to(raw_embed_chars)],dim=1)

        for ind,(i,j) in enumerate(zip(seq_len,lex_num)):
            # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
            # lex_num是list，是每个instance匹配到词的个数。
            # 最后加pad，确保和lattice的维度一致。
            chars_words = torch.cat([raw_embed_chars4lex[ind][:i],raw_embed_words[ind][:j]],dim=0) #[125, 50],[54, 50]->[179,50]
            if is_phrase:
                pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.phrase_input_size]).to(raw_embed_chars) #[10,50]
            else:
                pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.lex_input_size]).to(raw_embed_chars) #[10,50]
            chars_words_pads = torch.cat([chars_words,pads_temp],dim=0)
            raw_embed[ind] = chars_words_pads

        # for ind,(i,j) in enumerate(zip(seq_len,lex_num)):
        #     # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
        #     # lex_num是list，是每个instance匹配到词的个数。
        #     # 最后加pad，确保和lattice的维度一致。
        #     chars_words = torch.cat([raw_embed_chars[ind][:i],raw_embed_words[ind][:j]],dim=0) #[125, 50],[54, 50]->[179,50]
        #     pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.lex_input_size]).to(raw_embed_chars) #[10,50]
        #     chars_words_pads = torch.cat([chars_words,pads_temp],dim=0)
        #     raw_embed[ind] = chars_words_pads

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            # raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
            raw_embed_char = torch.cat([raw_embed_chars4bigram, bigrams_embed],dim=-1) # raw_embed_char:[10,102,100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))

        if self.use_bert:
            bert_pad_length = lattice.size(1)-max_seq_len # lattice.size(1): 211; max_seq_len: 141; pad_length: 70
            
            # char_for_bert = lattice[:, :max_seq_len]
            char_for_bert = chars

            mask = seq_len_to_mask(seq_len).bool()
            char_for_bert = char_for_bert.masked_fill((~mask),self.vocabs['lattice'].padding_idx)
            
            # 老版本，需要2个bert，为2个bert都要设置不同的学习率。
            # if not is_phrase:
            #     bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            # else:
            #     bert_embed = self.bert_embedding_phrase(char_for_bert) # torch.Size([10, 141, 768])

            bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            
            bert_embed = torch.cat([bert_embed,
                                    torch.zeros(size=[batch_size,bert_pad_length,bert_embed.size(-1)],
                                                device = bert_embed.device,
                                                requires_grad=False)],dim=-2)
            # print('bert_embed:{}'.format(bert_embed[:1, :3, -5:]))
            raw_embed_char = torch.cat([raw_embed_char, bert_embed],dim=-1) #执行之前，raw:[10, 211, 100]

        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]
        
        if is_phrase:
            embed_lex = self.phrase_proj(raw_embed)#[10, 196, 128]
        else:
            embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

    def initial_parameters(self, chars, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]

        if not is_phrase:
            # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
            raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
            #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        else:
            raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2

        if self.use_bert:
            bert_pad_length = lattice.size(1)-max_seq_len # lattice.size(1): 211; max_seq_len: 141; pad_length: 70
            
            # char_for_bert = lattice[:, :max_seq_len]
            char_for_bert = chars

            mask = seq_len_to_mask(seq_len).bool()
            char_for_bert = char_for_bert.masked_fill((~mask),self.vocabs['lattice'].padding_idx)
            
            # 老版本，需要2个bert，为2个bert都要设置不同的学习率。
            # if not is_phrase:
            #     bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            # else:
            #     bert_embed = self.bert_embedding_phrase(char_for_bert) # torch.Size([10, 141, 768])

            bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            
            bert_embed = torch.cat([bert_embed,
                                    torch.zeros(size=[batch_size,bert_pad_length,bert_embed.size(-1)],
                                                device = bert_embed.device,
                                                requires_grad=False)],dim=-2)
            # print('bert_embed:{}'.format(bert_embed[:1, :3, -5:]))
            raw_embed_char = torch.cat([raw_embed_char, bert_embed],dim=-1) #执行之前，raw:[10, 211, 100]

        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]

        embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

# not support only cross
# # 将phrase_lattice_embed用chars,phrases替换
class Cross_Lattice_Transformer_SeqLabel_Online1130(nn.Module):
    def __init__(self, online, char_embed, words_embed, phrases_embed, bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos,use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',
                 four_pos_shared=True,four_pos_fusion=None,four_pos_fusion_shared=True,
                 bert_embedding=None,use_pytorch_dropout=False,
                 residual = 'no',domain_join = False, general_join = False, gate = False, cross = False):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化

        :param embed_dropout_pos: 如果是0，就直接在embed后dropout，是1就在embed变成hidden size之后再dropout，
        是2就在绝对位置加上之后dropout
        '''
        super().__init__()

        # TODO: Modified Mark: add domain_join, general_join params.
        self.domain_join = domain_join
        self.general_join = general_join

        self.cross = cross

        self.use_bert = False
        if bert_embedding is not None:
            self.use_bert = True
            self.bert_embedding = bert_embedding

        self.use_pytorch_dropout = use_pytorch_dropout
        self.four_pos_fusion_shared = four_pos_fusion_shared
        self.mode = mode
        self.four_pos_shared = four_pos_shared
        self.abs_pos_fusion_func = abs_pos_fusion_func

        # self.lattice_embed = lattice_embed
        self.words_embed = words_embed


        # self.phrase_lattice_embed = phrase_lattice_embed
        self.char_embed = char_embed
        self.phrases_embed = phrases_embed

        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        # self.relative_position = relative_position
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        if self.use_rel_pos:
            assert four_pos_fusion is not None
        self.four_pos_fusion = four_pos_fusion
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init
        self.embed_dropout_pos = embed_dropout_pos


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)

        # if self.add_position:
        #     print('暂时只支持位置编码的concat模式')
        #     exit(1208)

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None

        if self.use_abs_pos:
            self.abs_pos_encode = Absolute_SE_Position_Embedding(self.abs_pos_fusion_func,
                                        self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                        pos_norm=self.pos_norm)

        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
            if self.four_pos_shared:
                self.pe_ss = self.pe
                self.pe_se = self.pe
                self.pe_es = self.pe
                self.pe_ee = self.pe
            else:
                self.pe_ss = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_se = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_es = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_ee = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
        else:
            self.pe = None
            self.pe_ss = None
            self.pe_se = None
            self.pe_es = None
            self.pe_ee = None






        # if self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        if self.use_bigram:
            self.bigram_size = self.bigram_embed.embedding.weight.size(1) # bigram.weight.shape:[107941, 50], size(1):50
            # lattice.weight.shape: [33357, 50], self.char_input_size:100, phrase.weight.shape:[39424, 50]
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            # self.char_input_size = self.lattice_embed.embedding.weight.size(1)
            self.char_input_size = self.char_embed.embedding.weight.size(1)

        if self.use_bert:
            self.char_input_size+=self.bert_embedding._embed_size

        # self.lex_input_size = self.lattice_embed.embedding.weight.size(1) #50
        # lex size是word size
        self.lex_input_size = self.words_embed.embedding.weight.size(1) #50
        # phrase可能是pretrained，也可能是online的
        if online == 'static':
            self.phrase_input_size = self.phrases_embed.embedding.weight.size(1) #50
        else:
            self.phrase_input_size = self.phrases_embed.embed_size 
        

        if use_pytorch_dropout:
            self.embed_dropout = nn.Dropout(self.dropout['embed'])
            self.gaz_dropout = nn.Dropout(self.dropout['gaz'])
            self.output_dropout = nn.Dropout(self.dropout['output'])
        else:
            self.embed_dropout = MyDropout(self.dropout['embed'])
            self.gaz_dropout = MyDropout(self.dropout['gaz'])
            self.output_dropout = MyDropout(self.dropout['output'])


        self.char_proj = nn.Linear(self.char_input_size,self.hidden_size)
        self.lex_proj = nn.Linear(self.lex_input_size,self.hidden_size)
        self.phrase_proj = nn.Linear(self.phrase_input_size,self.hidden_size)

        self.residual = residual

        self.encoder = self.get_encoder()
        self.phrase_encoder = self.get_encoder()

        # self.output = nn.Linear(self.hidden_size,self.label_size)
        # self.output = nn.Linear(self.hidden_size*2,self.label_size)

        # TODO: Modified Mark: add join.
        is_join = self.domain_join or self.general_join
        if is_join or gate:
            self.output = nn.Linear(self.hidden_size,self.label_size)
        # cross时，维度变大。
        else:
            self.output = nn.Linear(self.hidden_size*2,self.label_size)

        if cross or is_join :
            # TODO: Modified Mark: update encoder.
            self.cross_encoder = self.get_cross_encoder()

        self.gate = gate
        if gate:
            self.cat2gatess_1 = nn.Linear(self.hidden_size, self.hidden_size)
            self.cat2gatess_2 = nn.Linear(self.hidden_size*2, self.hidden_size)
            self.cat2gatess_3 = nn.Linear(self.hidden_size, self.hidden_size)

        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
        self.batch_num = 0
    
    # TODO: Modified Mark: update encoder.
    def get_cross_encoder(self):
        # cross attention先不考虑rel position，因为有两套position，不好计算rel pos。
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=False,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)

    def get_encoder(self):
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)


    def forward(self, words, lattice, chars, phrases, phrase_lattice, bigrams, seq_len, lex_num, phrase_num, pos_s, pos_e, phrase_pos_s, phrase_pos_e,
                target, chars_target=None):
        # if self.training:
        #     self.batch_num+=1
        # if self.batch_num == 1000:
        #     exit()

        # print('lattice:')
        # print(lattice)
        
        # initial返回的结果中，只有emb不一样
        # dim2, dim3没什么用，只是调试用的
        # domain词典是online计算的，general词典不用online计算。
        # batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters(chars, lattice, bigrams, seq_len, lex_num, pos_s, pos_e)
        batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters_online(chars, words, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False)
        batch_size, max_seq_len, dim2, dim3, phrase_embedding = self.initial_parameters_online(chars, phrases, phrase_lattice, bigrams, seq_len, phrase_num, phrase_pos_s, phrase_pos_e, is_phrase=True)

        encoded = self.encoder(embedding,embedding,embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                               print_=(self.batch_num==327))

        phrase_encoded = self.phrase_encoder(phrase_embedding,phrase_embedding,phrase_embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
                               print_=(self.batch_num==327))

        ### old version ###
        # encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
        # phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
        # # pos_e.shape: [10, 196]; phrase_pos_s.shape: [10, 219]
        # pos_s = pos_s[:,:max_seq_len]
        # pos_e = pos_e[:,:max_seq_len]
        # encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num=0,pos_s=pos_s,pos_e=pos_s)
        # phrase_encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,lex_num=0,pos_s=pos_s,pos_e=pos_s)

        # if self.batch_num == 327:
        #     print('{} encoded:{}'.format(self.batch_num,
        #                                encoded[:2,dim2,:dim3]))

        
        # # if hasattr(self,'output_dropout'):
        # #     encoded = self.output_dropout(encoded)
        # #     phrase_encoded = self.output_dropout(phrase_encoded)

        # # encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
        # # phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
        # # encoded = torch.cat([encoded, phrase_encoded], dim=-1)

        # if hasattr(self,'output_dropout'):
        #     encoded_cross = self.output_dropout(encoded_cross)
        #     phrase_encoded_cross = self.output_dropout(phrase_encoded_cross)

        # encoded = torch.cat([encoded_cross, phrase_encoded_cross], dim=-1)

        # TODO: Modified Mark: add join and update cross.
        ### new version ###
        is_joint = self.domain_join or self.general_join
        # self.domain_join and self.general_join不能同时为true
        # assert self.domain_join and self.general_join

        if is_joint:
            # domain_join：general给domain增强。
            if self.domain_join:
                encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num=lex_num)    
                # if hasattr(self,'output_dropout'):
                #     encoded_cross = self.output_dropout(encoded_cross)
                encoded = encoded_cross[:,:max_seq_len,:]
            elif self.general_join:
                encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,lex_num=phrase_num)    
                # if hasattr(self,'output_dropout'):
                #     encoded_cross = self.output_dropout(encoded_cross)
                encoded = encoded_cross[:,:max_seq_len,:]
        else:
            if self.cross:
                encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num) # q, k, v
                phrase_encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,phrase_num)

                if self.batch_num == 327:
                    print('{} encoded:{}'.format(self.batch_num,
                                            encoded[:2,dim2,:dim3]))

                
                # if hasattr(self,'output_dropout'):
                # encoded_cross = self.output_dropout(encoded_cross)
                # phrase_encoded_cross = self.output_dropout(phrase_encoded_cross)        

                # encoded_cross = encoded_cross[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                # phrase_encoded_cross = phrase_encoded_cross[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]

                # encoded = encoded_cross[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                # phrase_encoded = phrase_encoded_cross[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]

                encoded = encoded_cross
                phrase_encoded = phrase_encoded_cross

            # if self.gate:
            #     h1 = torch.tanh(self.cat2gatess_3(encoded_cross))
            #     h2 = torch.tanh(self.cat2gatess_1(phrase_encoded_cross))
            #     g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
            #     encoded = g1 * encoded_cross + (1 - g1) * phrase_encoded_cross
            # else:
            #     encoded = torch.cat([encoded_cross, phrase_encoded_cross], dim=-1)

            if self.gate:
                encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                h1 = torch.tanh(self.cat2gatess_3(encoded))
                h2 = torch.tanh(self.cat2gatess_1(phrase_encoded))
                g1 = torch.sigmoid(self.cat2gatess_2(torch.cat((h1, h2), dim=-1)))
                encoded = g1 * encoded + (1 - g1) * phrase_encoded
            else:
                encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
                phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
                encoded = torch.cat([encoded, phrase_encoded], dim=-1)

        # 要在最后dropout。不要在前面dropout。
        if hasattr(self,'output_dropout'):
            # encoded_cross = self.output_dropout(encoded_cross)
            # phrase_encoded_cross = self.output_dropout(phrase_encoded_cross)
            encoded = self.output_dropout(encoded)

        pred = self.output(encoded)

        if self.batch_num == 327:
            print('{} pred:{}'.format(self.batch_num,
                                       pred[:2,dim2,:dim3]))

        # print('pred:{}'.format(pred[:,dim2,:dim3]))
        # exit()

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss

            if self.batch_num == 327:
                print('{} loss:{}'.format(self.batch_num,loss))
                exit()

            # exit()
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result

    def initial_parameters_online(self, chars, phrases, lattice,bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        # max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]
        max_seq_len = chars.size(1)

        # if not is_phrase:
        #     # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
        #     raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
        #     #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        # else:
        #     raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        # raw_embed是给lex用的，raw_embed_char是给char用的
        raw_embed_chars = self.char_embed(chars)
        if is_phrase:
            raw_embed_words = self.phrases_embed(phrases)
            raw_embed = torch.zeros(size=[batch_size,max_seq_len_and_lex_num,self.phrase_input_size]).to(raw_embed_chars)
        else:
            raw_embed_words = self.words_embed(phrases)
            raw_embed = torch.zeros(size=[batch_size,max_seq_len_and_lex_num,self.lex_input_size]).to(raw_embed_chars)

        
        
        char_size = self.char_embed.embedding.weight.size(1)
        # if char_size != self.lex_input_size:
        # 假设lex可能大约char的维度。需要对char补0来对齐维度。
        # 如果char的维度大于lex的维度，则需要对lex补0来对齐维度。
        assert char_size <= self.lex_input_size
        # 可能char：50维，lex：200维。
        # 为了和lex进行concat，用0来增加了维度。
        # 但这部分维度其实不需要，所以单独做raw_embed_chars4bigram，用来char+bigram+bert。
        # raw_embed_chars = self.char_proj2lex(raw_embed_chars)
        if is_phrase:
            raw_embed_chars4lex = torch.cat([raw_embed_chars,torch.zeros(size=[batch_size,max_seq_len,self.phrase_input_size-char_size]).to(raw_embed_chars)],dim=-1)
        else:
            raw_embed_chars4lex = torch.cat([raw_embed_chars,torch.zeros(size=[batch_size,max_seq_len,self.lex_input_size-char_size]).to(raw_embed_chars)],dim=-1)
        
        # char和bigram维度一样
        raw_embed_chars4bigram = torch.cat([raw_embed_chars,
                                    torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                        char_size]).to(raw_embed_chars)],dim=1)

        for ind,(i,j) in enumerate(zip(seq_len,lex_num)):
            # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
            # lex_num是list，是每个instance匹配到词的个数。
            # 最后加pad，确保和lattice的维度一致。
            chars_words = torch.cat([raw_embed_chars4lex[ind][:i],raw_embed_words[ind][:j]],dim=0) #[125, 50],[54, 50]->[179,50]
            if is_phrase:
                pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.phrase_input_size]).to(raw_embed_chars) #[10,50]
            else:
                pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.lex_input_size]).to(raw_embed_chars) #[10,50]
            chars_words_pads = torch.cat([chars_words,pads_temp],dim=0)
            raw_embed[ind] = chars_words_pads

        # for ind,(i,j) in enumerate(zip(seq_len,lex_num)):
        #     # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
        #     # lex_num是list，是每个instance匹配到词的个数。
        #     # 最后加pad，确保和lattice的维度一致。
        #     chars_words = torch.cat([raw_embed_chars[ind][:i],raw_embed_words[ind][:j]],dim=0) #[125, 50],[54, 50]->[179,50]
        #     pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.lex_input_size]).to(raw_embed_chars) #[10,50]
        #     chars_words_pads = torch.cat([chars_words,pads_temp],dim=0)
        #     raw_embed[ind] = chars_words_pads

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            # raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
            raw_embed_char = torch.cat([raw_embed_chars4bigram, bigrams_embed],dim=-1) # raw_embed_char:[10,102,100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))

        if self.use_bert:
            bert_pad_length = lattice.size(1)-max_seq_len # lattice.size(1): 211; max_seq_len: 141; pad_length: 70
            
            # char_for_bert = lattice[:, :max_seq_len]
            char_for_bert = chars

            mask = seq_len_to_mask(seq_len).bool()
            char_for_bert = char_for_bert.masked_fill((~mask),self.vocabs['lattice'].padding_idx)
            
            # 老版本，需要2个bert，为2个bert都要设置不同的学习率。
            # if not is_phrase:
            #     bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            # else:
            #     bert_embed = self.bert_embedding_phrase(char_for_bert) # torch.Size([10, 141, 768])

            bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            
            bert_embed = torch.cat([bert_embed,
                                    torch.zeros(size=[batch_size,bert_pad_length,bert_embed.size(-1)],
                                                device = bert_embed.device,
                                                requires_grad=False)],dim=-2)
            # print('bert_embed:{}'.format(bert_embed[:1, :3, -5:]))
            raw_embed_char = torch.cat([raw_embed_char, bert_embed],dim=-1) #执行之前，raw:[10, 211, 100]

        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]
        
        if is_phrase:
            embed_lex = self.phrase_proj(raw_embed)#[10, 196, 128]
        else:
            embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

    def initial_parameters(self, chars, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]

        if not is_phrase:
            # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
            raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
            #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        else:
            raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2

        if self.use_bert:
            bert_pad_length = lattice.size(1)-max_seq_len # lattice.size(1): 211; max_seq_len: 141; pad_length: 70
            
            # char_for_bert = lattice[:, :max_seq_len]
            char_for_bert = chars

            mask = seq_len_to_mask(seq_len).bool()
            char_for_bert = char_for_bert.masked_fill((~mask),self.vocabs['lattice'].padding_idx)
            
            # 老版本，需要2个bert，为2个bert都要设置不同的学习率。
            # if not is_phrase:
            #     bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            # else:
            #     bert_embed = self.bert_embedding_phrase(char_for_bert) # torch.Size([10, 141, 768])

            bert_embed = self.bert_embedding(char_for_bert) # torch.Size([10, 141, 768])    
            
            bert_embed = torch.cat([bert_embed,
                                    torch.zeros(size=[batch_size,bert_pad_length,bert_embed.size(-1)],
                                                device = bert_embed.device,
                                                requires_grad=False)],dim=-2)
            # print('bert_embed:{}'.format(bert_embed[:1, :3, -5:]))
            raw_embed_char = torch.cat([raw_embed_char, bert_embed],dim=-1) #执行之前，raw:[10, 211, 100]

        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]

        embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

# 将phrase_lattice_embed用chars,phrases替换
# 这个是截断方式实现的cross-attention。
class Cross_Lattice_Transformer_SeqLabel_Online_bak(nn.Module):
    def __init__(self, lattice_embed, char_embed, phrases_embed, bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos,use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',
                 four_pos_shared=True,four_pos_fusion=None,four_pos_fusion_shared=True,
                 bert_embedding=None,use_pytorch_dropout=False,
                 residual = 'no'):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化

        :param embed_dropout_pos: 如果是0，就直接在embed后dropout，是1就在embed变成hidden size之后再dropout，
        是2就在绝对位置加上之后dropout
        '''
        super().__init__()
        self.use_pytorch_dropout = use_pytorch_dropout
        self.four_pos_fusion_shared = four_pos_fusion_shared
        self.mode = mode
        self.four_pos_shared = four_pos_shared
        self.abs_pos_fusion_func = abs_pos_fusion_func

        self.lattice_embed = lattice_embed

        # self.phrase_lattice_embed = phrase_lattice_embed
        self.char_embed = char_embed
        self.phrases_embed = phrases_embed

        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        # self.relative_position = relative_position
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        if self.use_rel_pos:
            assert four_pos_fusion is not None
        self.four_pos_fusion = four_pos_fusion
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init
        self.embed_dropout_pos = embed_dropout_pos


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)

        # if self.add_position:
        #     print('暂时只支持位置编码的concat模式')
        #     exit(1208)

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None

        if self.use_abs_pos:
            self.abs_pos_encode = Absolute_SE_Position_Embedding(self.abs_pos_fusion_func,
                                        self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                        pos_norm=self.pos_norm)

        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
            if self.four_pos_shared:
                self.pe_ss = self.pe
                self.pe_se = self.pe
                self.pe_es = self.pe
                self.pe_ee = self.pe
            else:
                self.pe_ss = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_se = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_es = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_ee = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
        else:
            self.pe = None
            self.pe_ss = None
            self.pe_se = None
            self.pe_es = None
            self.pe_ee = None






        # if self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        if self.use_bigram:
            self.bigram_size = self.bigram_embed.embedding.weight.size(1) # bigram.weight.shape:[107941, 50], size(1):50
            # lattice.weight.shape: [33357, 50], self.char_input_size:100, phrase.weight.shape:[39424, 50]
            self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            self.char_input_size = self.lattice_embed.embedding.weight.size(1)

        # 假设lattice_emb和phrase_emb的维度相同
        self.lex_input_size = self.lattice_embed.embedding.weight.size(1) #50
        

        if use_pytorch_dropout:
            self.embed_dropout = nn.Dropout(self.dropout['embed'])
            self.gaz_dropout = nn.Dropout(self.dropout['gaz'])
            self.output_dropout = nn.Dropout(self.dropout['output'])
        else:
            self.embed_dropout = MyDropout(self.dropout['embed'])
            self.gaz_dropout = MyDropout(self.dropout['gaz'])
            self.output_dropout = MyDropout(self.dropout['output'])


        self.char_proj = nn.Linear(self.char_input_size,self.hidden_size)
        self.lex_proj = nn.Linear(self.lex_input_size,self.hidden_size)

        self.residual = residual

        self.encoder = self.get_encoder()
        self.phrase_encoder = self.get_encoder()

        self.cross_encoder = self.get_encoder()

        # self.output = nn.Linear(self.hidden_size,self.label_size)
        self.output = nn.Linear(self.hidden_size*2,self.label_size)

        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
        self.batch_num = 0

    def get_encoder(self):
        return Cross_Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)


    def forward(self, lattice, chars, phrases, phrase_lattice, bigrams, seq_len, lex_num, phrase_num, pos_s, pos_e, phrase_pos_s, phrase_pos_e,
                target, chars_target=None):
        # if self.training:
        #     self.batch_num+=1
        # if self.batch_num == 1000:
        #     exit()

        # print('lattice:')
        # print(lattice)
        
        # initial返回的结果中，只有emb不一样
        # dim2, dim3没什么用，只是调试用的
        # domain词典是online计算的，general词典不用online计算。
        batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters(lattice, bigrams, seq_len, lex_num, pos_s, pos_e)
        batch_size, max_seq_len, dim2, dim3, phrase_embedding = self.initial_parameters_online(chars, phrases, phrase_lattice, bigrams, seq_len, phrase_num, phrase_pos_s, phrase_pos_e, is_phrase=True)

        encoded = self.encoder(embedding,embedding,embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                               print_=(self.batch_num==327))

        phrase_encoded = self.phrase_encoder(phrase_embedding,phrase_embedding,phrase_embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
                               print_=(self.batch_num==327))

        encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
        phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
        # pos_e.shape: [10, 196]; phrase_pos_s.shape: [10, 219]
        pos_s = pos_s[:,:max_seq_len]
        pos_e = pos_e[:,:max_seq_len]
        encoded_cross = self.cross_encoder(phrase_encoded,encoded,encoded,seq_len,lex_num=0,pos_s=pos_s,pos_e=pos_s)
        phrase_encoded_cross = self.cross_encoder(encoded,phrase_encoded,phrase_encoded,seq_len,lex_num=0,pos_s=pos_s,pos_e=pos_s)

        if self.batch_num == 327:
            print('{} encoded:{}'.format(self.batch_num,
                                       encoded[:2,dim2,:dim3]))

        
        # if hasattr(self,'output_dropout'):
        #     encoded = self.output_dropout(encoded)
        #     phrase_encoded = self.output_dropout(phrase_encoded)

        # encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
        # phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
        # encoded = torch.cat([encoded, phrase_encoded], dim=-1)

        if hasattr(self,'output_dropout'):
            encoded_cross = self.output_dropout(encoded_cross)
            phrase_encoded_cross = self.output_dropout(phrase_encoded_cross)

        encoded = torch.cat([encoded_cross, phrase_encoded_cross], dim=-1)

        pred = self.output(encoded)

        if self.batch_num == 327:
            print('{} pred:{}'.format(self.batch_num,
                                       pred[:2,dim2,:dim3]))

        # print('pred:{}'.format(pred[:,dim2,:dim3]))
        # exit()

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss

            if self.batch_num == 327:
                print('{} loss:{}'.format(self.batch_num,loss))
                exit()

            # exit()
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result

    def initial_parameters_online(self, chars, phrases, lattice,bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        # max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]
        max_seq_len = chars.size(1)

        # if not is_phrase:
        #     # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
        #     raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
        #     #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        # else:
        #     raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        raw_embed_chars = self.char_embed(chars)
        raw_embed_words = self.phrases_embed(phrases)

        raw_embed = torch.zeros(size=[batch_size,max_seq_len_and_lex_num,self.lex_input_size]).to(raw_embed_chars)

        for ind,(i,j) in enumerate(zip(seq_len,lex_num)):
            # 因此chars_words中有pad，会影响index，所以只保留非pad部分【即seq_len】。
            # lex_num是list，是每个instance匹配到词的个数。
            # 最后加pad，确保和lattice的维度一致。
            chars_words = torch.cat([raw_embed_chars[ind][:i],raw_embed_words[ind][:j]],dim=0) #[125, 50],[54, 50]->[179,50]
            pads_temp = torch.zeros(size=[max_seq_len_and_lex_num-i-j, self.lex_input_size]).to(raw_embed_chars) #[10,50]
            chars_words_pads = torch.cat([chars_words,pads_temp],dim=0)
            raw_embed[ind] = chars_words_pads

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]

        embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

    def initial_parameters(self, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]

        if not is_phrase:
            # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
            raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
            #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        else:
            raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]

        embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding


class Dual_Lattice_Transformer_SeqLabel(nn.Module):
    def __init__(self,lattice_embed, phrase_lattice_embed , bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos,use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',
                 four_pos_shared=True,four_pos_fusion=None,four_pos_fusion_shared=True,
                 bert_embedding=None,use_pytorch_dropout=False,
                 residual = 'no'):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化

        :param embed_dropout_pos: 如果是0，就直接在embed后dropout，是1就在embed变成hidden size之后再dropout，
        是2就在绝对位置加上之后dropout
        '''
        super().__init__()
        self.use_pytorch_dropout = use_pytorch_dropout
        self.four_pos_fusion_shared = four_pos_fusion_shared
        self.mode = mode
        self.four_pos_shared = four_pos_shared
        self.abs_pos_fusion_func = abs_pos_fusion_func

        self.lattice_embed = lattice_embed
        self.phrase_lattice_embed = phrase_lattice_embed

        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        # self.relative_position = relative_position
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        if self.use_rel_pos:
            assert four_pos_fusion is not None
        self.four_pos_fusion = four_pos_fusion
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init
        self.embed_dropout_pos = embed_dropout_pos


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)

        # if self.add_position:
        #     print('暂时只支持位置编码的concat模式')
        #     exit(1208)

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None

        if self.use_abs_pos:
            self.abs_pos_encode = Absolute_SE_Position_Embedding(self.abs_pos_fusion_func,
                                        self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                        pos_norm=self.pos_norm)

        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
            if self.four_pos_shared:
                self.pe_ss = self.pe
                self.pe_se = self.pe
                self.pe_es = self.pe
                self.pe_ee = self.pe
            else:
                self.pe_ss = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_se = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_es = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_ee = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
        else:
            self.pe = None
            self.pe_ss = None
            self.pe_se = None
            self.pe_es = None
            self.pe_ee = None






        # if self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        if self.use_bigram:
            self.bigram_size = self.bigram_embed.embedding.weight.size(1) # bigram.weight.shape:[107941, 50], size(1):50
            # lattice.weight.shape: [33357, 50], self.char_input_size:100, phrase.weight.shape:[39424, 50]
            self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            self.char_input_size = self.lattice_embed.embedding.weight.size(1)

        self.lex_input_size = self.lattice_embed.embedding.weight.size(1) #50

        if use_pytorch_dropout:
            self.embed_dropout = nn.Dropout(self.dropout['embed'])
            self.gaz_dropout = nn.Dropout(self.dropout['gaz'])
            self.output_dropout = nn.Dropout(self.dropout['output'])
        else:
            self.embed_dropout = MyDropout(self.dropout['embed'])
            self.gaz_dropout = MyDropout(self.dropout['gaz'])
            self.output_dropout = MyDropout(self.dropout['output'])


        self.char_proj = nn.Linear(self.char_input_size,self.hidden_size)
        self.lex_proj = nn.Linear(self.lex_input_size,self.hidden_size)

        self.residual = residual

        self.encoder = self.get_encoder()
        self.phrase_encoder = self.get_encoder()


        # self.cross_encoder = self.get_encoder()

        # self.output = nn.Linear(self.hidden_size,self.label_size)
        self.output = nn.Linear(self.hidden_size*2,self.label_size)

        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
        self.batch_num = 0

    def get_encoder(self):
        return Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = self.residual)


    def forward(self, lattice, phrase_lattice, bigrams, seq_len, lex_num, phrase_num, pos_s, pos_e, phrase_pos_s, phrase_pos_e,
                target, chars_target=None):
        # if self.training:
        #     self.batch_num+=1
        # if self.batch_num == 1000:
        #     exit()

        # print('lattice:')
        # print(lattice)
        
        # initial返回的结果中，只有emb不一样
        # dim2, dim3没啥用，只是调试用的
        batch_size, max_seq_len, dim2, dim3, embedding = self.initial_parameters(lattice, bigrams, seq_len, lex_num, pos_s, pos_e)
        batch_size, max_seq_len, dim2, dim3, phrase_embedding = self.initial_parameters(phrase_lattice, bigrams, seq_len, phrase_num, phrase_pos_s, phrase_pos_e, is_phrase=True)

        encoded = self.encoder(embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                               print_=(self.batch_num==327))

        phrase_encoded = self.phrase_encoder(phrase_embedding,seq_len,lex_num=phrase_num,pos_s=phrase_pos_s,pos_e=phrase_pos_e,
                               print_=(self.batch_num==327))



        if self.batch_num == 327:
            print('{} encoded:{}'.format(self.batch_num,
                                       encoded[:2,dim2,:dim3]))

        
        if hasattr(self,'output_dropout'):
            encoded = self.output_dropout(encoded)
            phrase_encoded = self.output_dropout(phrase_encoded)

        encoded = encoded[:,:max_seq_len,:] #[10, 196, 128]->[10, 149, 128]
        phrase_encoded = phrase_encoded[:,:max_seq_len,:] #[10, 219, 128]->[10, 149, 128]
        encoded = torch.cat([encoded, phrase_encoded], dim=-1)

        pred = self.output(encoded)

        if self.batch_num == 327:
            print('{} pred:{}'.format(self.batch_num,
                                       pred[:2,dim2,:dim3]))

        # print('pred:{}'.format(pred[:,dim2,:dim3]))
        # exit()

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss

            if self.batch_num == 327:
                print('{} loss:{}'.format(self.batch_num,loss))
                exit()

            # exit()
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result

    def initial_parameters(self, lattice, bigrams, seq_len, lex_num, pos_s, pos_e, is_phrase=False):
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)#phrase_lattice.shape:[10,219], lattice.shape:[10,196]
        max_seq_len_and_lex_num = lattice.size(1)
        max_seq_len = bigrams.size(1)#bigrams.shape:[10,149]

        if not is_phrase:
            # raw_embed = self.lattice_embed(phrase_lattice)#raw_emb.shape:[10,219,50]
            raw_embed = self.lattice_embed(lattice)#raw_emb.shape:[10,219,50]
            #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        else:
            raw_embed = self.phrase_lattice_embed(lattice)#raw_emb.shape:[10,219,50]

        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)#[10, 149, 50]
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)#[10, 196, 50]
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)#[10, 196, 100]
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()#[10, 196]
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0) #mask pad和lex的部分 [10, 196, 128]

        embed_lex = self.lex_proj(raw_embed)#[10, 196, 128]
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())#[10, 196]
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0) #mask pad和char的部分

        assert char_mask.size(1) == lex_mask.size(1)
        # embed_lex:[10,219,128], embed_char:[10,219,128]，embedding = [10,219,128]
        # 为啥不直接mask pad部分，而是分别mask？可能是因为虽然都是lattice，但经历了不同的映射char_proj,lex_proj。
        embedding = embed_char + embed_lex #[10, 196, 128]
        
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))
                                       
        return batch_size,max_seq_len,dim2,dim3,embedding

class Lattice_Transformer_SeqLabel(nn.Module):
    def __init__(self,lattice_embed, bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos,use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',
                 four_pos_shared=True,four_pos_fusion=None,four_pos_fusion_shared=True,
                 bert_embedding=None,use_pytorch_dropout=False,
                 residual = 'no'):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化

        :param embed_dropout_pos: 如果是0，就直接在embed后dropout，是1就在embed变成hidden size之后再dropout，
        是2就在绝对位置加上之后dropout
        '''
        super().__init__()
        self.use_pytorch_dropout = use_pytorch_dropout
        self.four_pos_fusion_shared = four_pos_fusion_shared
        self.mode = mode
        self.four_pos_shared = four_pos_shared
        self.abs_pos_fusion_func = abs_pos_fusion_func
        self.lattice_embed = lattice_embed
        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        # self.relative_position = relative_position
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        if self.use_rel_pos:
            assert four_pos_fusion is not None
        self.four_pos_fusion = four_pos_fusion
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init
        self.embed_dropout_pos = embed_dropout_pos


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)

        # if self.add_position:
        #     print('暂时只支持位置编码的concat模式')
        #     exit(1208)

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None

        if self.use_abs_pos:
            self.abs_pos_encode = Absolute_SE_Position_Embedding(self.abs_pos_fusion_func,
                                        self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                        pos_norm=self.pos_norm)

        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
            if self.four_pos_shared:
                self.pe_ss = self.pe
                self.pe_se = self.pe
                self.pe_es = self.pe
                self.pe_ee = self.pe
            else:
                self.pe_ss = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_se = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_es = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
                self.pe_ee = nn.Parameter(copy.deepcopy(pe),requires_grad=self.learnable_position)
        else:
            self.pe = None
            self.pe_ss = None
            self.pe_se = None
            self.pe_es = None
            self.pe_ee = None






        # if self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        if self.use_bigram:
            self.bigram_size = self.bigram_embed.embedding.weight.size(1)
            self.char_input_size = self.lattice_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            self.char_input_size = self.lattice_embed.embedding.weight.size(1)

        self.lex_input_size = self.lattice_embed.embedding.weight.size(1)

        if use_pytorch_dropout:
            self.embed_dropout = nn.Dropout(self.dropout['embed'])
            self.gaz_dropout = nn.Dropout(self.dropout['gaz'])
            self.output_dropout = nn.Dropout(self.dropout['output'])
        else:
            self.embed_dropout = MyDropout(self.dropout['embed'])
            self.gaz_dropout = MyDropout(self.dropout['gaz'])
            self.output_dropout = MyDropout(self.dropout['output'])


        self.char_proj = nn.Linear(self.char_input_size,self.hidden_size)
        self.lex_proj = nn.Linear(self.lex_input_size,self.hidden_size)

        self.encoder = Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           pe_ss=self.pe_ss,
                                           pe_se=self.pe_se,
                                           pe_es=self.pe_es,
                                           pe_ee=self.pe_ee,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           lattice=True,
                                           four_pos_fusion=self.four_pos_fusion,
                                           four_pos_fusion_shared=self.four_pos_fusion_shared,
                                           use_pytorch_dropout=self.use_pytorch_dropout,
                                           residual = residual)


        self.output = nn.Linear(self.hidden_size,self.label_size)
        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
        self.batch_num = 0


    def forward(self, lattice, bigrams, seq_len, lex_num, pos_s, pos_e,
                target, chars_target=None):
        # if self.training:
        #     self.batch_num+=1
        # if self.batch_num == 1000:
        #     exit()

        # print('lattice:')
        # print(lattice)
        if self.mode['debug']:
            print('lattice:{}'.format(lattice))
            print('bigrams:{}'.format(bigrams))
            print('seq_len:{}'.format(seq_len))
            print('lex_num:{}'.format(lex_num))
            print('pos_s:{}'.format(pos_s))
            print('pos_e:{}'.format(pos_e))

        batch_size = lattice.size(0)
        max_seq_len_and_lex_num = lattice.size(1)
        max_seq_len = bigrams.size(1)

        raw_embed = self.lattice_embed(lattice)
        #raw_embed 是字和词的pretrain的embedding，但是是分别trian的，所以需要区分对待
        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)
            bigrams_embed = torch.cat([bigrams_embed,
                                       torch.zeros(size=[batch_size,max_seq_len_and_lex_num-max_seq_len,
                                                         self.bigram_size]).to(bigrams_embed)],dim=1)
            raw_embed_char = torch.cat([raw_embed, bigrams_embed],dim=-1)
        else:
            raw_embed_char = raw_embed

        dim2 = 0
        dim3 = 2
        # print('raw_embed:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char:{}'.format(raw_embed_char[:, dim2, :dim3]))
        if self.embed_dropout_pos == '0':
            raw_embed_char = self.embed_dropout(raw_embed_char)
            raw_embed = self.gaz_dropout(raw_embed)
        # print('raw_embed_dropout:{}'.format(raw_embed[:,dim2,:dim3]))
        # print('raw_embed_char_dropout:{}'.format(raw_embed_char[:, dim2, :dim3]))

        embed_char = self.char_proj(raw_embed_char)
        if self.mode['debug']:
            print('embed_char:{}'.format(embed_char[:2]))
        char_mask = seq_len_to_mask(seq_len,max_len=max_seq_len_and_lex_num).bool()
        # if self.embed_dropout_pos == '1':
        #     embed_char = self.embed_dropout(embed_char)
        embed_char.masked_fill_(~(char_mask.unsqueeze(-1)), 0)

        embed_lex = self.lex_proj(raw_embed)
        if self.mode['debug']:
            print('embed_lex:{}'.format(embed_lex[:2]))
        # if self.embed_dropout_pos == '1':
        #     embed_lex = self.embed_dropout(embed_lex)

        lex_mask = (seq_len_to_mask(seq_len+lex_num).bool() ^ char_mask.bool())
        embed_lex.masked_fill_(~(lex_mask).unsqueeze(-1), 0)

        assert char_mask.size(1) == lex_mask.size(1)

        embedding = embed_char + embed_lex
        if self.mode['debug']:
            print('embedding:{}'.format(embedding[:2]))

        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.abs_pos_encode(embedding,pos_s,pos_e)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)
        # embedding = self.embed_dropout(embedding)

        # print('embedding:{}'.format(embedding[:,dim2,:dim3]))

        if self.batch_num == 327:
            print('{} embed:{}'.format(self.batch_num,
                                       embedding[:2,dim2,:dim3]))

        encoded = self.encoder(embedding,seq_len,lex_num=lex_num,pos_s=pos_s,pos_e=pos_e,
                               print_=(self.batch_num==327))

        if self.batch_num == 327:
            print('{} encoded:{}'.format(self.batch_num,
                                       encoded[:2,dim2,:dim3]))

        if hasattr(self,'output_dropout'):
            encoded = self.output_dropout(encoded)


        encoded = encoded[:,:max_seq_len,:]
        pred = self.output(encoded)

        if self.batch_num == 327:
            print('{} pred:{}'.format(self.batch_num,
                                       pred[:2,dim2,:dim3]))

        # print('pred:{}'.format(pred[:,dim2,:dim3]))
        # exit()

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss

            if self.batch_num == 327:
                print('{} loss:{}'.format(self.batch_num,loss))
                exit()

            # exit()
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result


    # def train(self,mode=True):
    #     print('model mode get train ! mode:{}'.format(mode))
    #     super().train(mode)
    #
    # def eval(self):
    #     print('model mode get eval !')
    #     super().eval()




class Transformer_SeqLabel(nn.Module):
    def __init__(self,char_embed, bigram_embed, hidden_size, label_size,
                 num_heads, num_layers,
                 use_abs_pos, use_rel_pos, learnable_position,add_position,
                 layer_preprocess_sequence, layer_postprocess_sequence,
                 ff_size=-1, scaled=True , dropout=None,use_bigram=True,mode=collections.defaultdict(bool),
                 dvc=None,vocabs=None,
                 rel_pos_shared=True,max_seq_len=-1,k_proj=True,q_proj=True,v_proj=True,r_proj=True,
                 self_supervised=False,attn_ff=True,pos_norm=False,ff_activate='relu',rel_pos_init=0,
                 abs_pos_fusion_func='concat',embed_dropout_pos='0',):
        '''
        :param rel_pos_init: 如果是0，那么从-max_len到max_len的相对位置编码矩阵就按0-2*max_len来初始化，
        如果是1，那么就按-max_len,max_len来初始化
        '''
        super().__init__()
        self.abs_pos_fusion_func = abs_pos_fusion_func
        self.embed_dropout_pos = embed_dropout_pos
        self.mode = mode
        self.char_embed =char_embed
        self.bigram_embed = bigram_embed
        self.hidden_size = hidden_size
        self.label_size = label_size
        self.num_heads = num_heads
        self.num_layers = num_layers
        self.use_abs_pos = use_abs_pos
        self.use_rel_pos = use_rel_pos
        # self.relative_position = relative_position
        self.learnable_position = learnable_position
        self.add_position = add_position
        self.rel_pos_shared = rel_pos_shared
        self.self_supervised=self_supervised
        self.vocabs = vocabs
        self.attn_ff = attn_ff
        self.pos_norm = pos_norm
        self.ff_activate = ff_activate
        self.rel_pos_init = rel_pos_init

        if self.use_rel_pos and max_seq_len < 0:
            print_info('max_seq_len should be set if relative position encode')
            exit(1208)

        self.max_seq_len = max_seq_len

        self.k_proj = k_proj
        self.q_proj = q_proj
        self.v_proj = v_proj
        self.r_proj = r_proj

        self.pe = None
        if self.use_abs_pos:
            self.pos_encode = Absolute_Position_Embedding(self.abs_pos_fusion_func,
                                                          self.hidden_size,learnable=self.learnable_position,mode=self.mode,
                                                          pos_norm=self.pos_norm)


        if self.use_rel_pos:
            pe = get_embedding(max_seq_len,hidden_size,rel_pos_init=self.rel_pos_init)
            pe_sum = pe.sum(dim=-1,keepdim=True)
            if self.pos_norm:
                with torch.no_grad():
                    pe = pe/pe_sum
            self.pe = nn.Parameter(pe, requires_grad=self.learnable_position)
        else:
            self.pe = None


        # if self.relative_position:
        #     print('现在还不支持相对编码！')
        #     exit(1208)




        # if not self.add_position:
        #     print('现在还不支持位置编码通过concat的方式加入')
        #     exit(1208)

        self.layer_preprocess_sequence = layer_preprocess_sequence
        self.layer_postprocess_sequence = layer_postprocess_sequence
        if ff_size==-1:
            ff_size = self.hidden_size
        self.ff_size = ff_size
        self.scaled = scaled
        if dvc == None:
            dvc = 'cpu'
        self.dvc = torch.device(dvc)
        if dropout is None:
            self.dropout = collections.defaultdict(int)
        else:
            self.dropout = dropout
        self.use_bigram = use_bigram

        if self.use_bigram:
            self.input_size = self.char_embed.embedding.weight.size(1)+self.bigram_embed.embedding.weight.size(1)
        else:
            self.input_size = self.char_embed.embedding.weight.size(1)

        self.embed_dropout = nn.Dropout(self.dropout['embed'])
        self.w_proj = nn.Linear(self.input_size,self.hidden_size)
        self.encoder = Transformer_Encoder(self.hidden_size,self.num_heads,self.num_layers,
                                           relative_position=self.use_rel_pos,
                                           learnable_position=self.learnable_position,
                                           add_position=self.add_position,
                                           layer_preprocess_sequence=self.layer_preprocess_sequence,
                                           layer_postprocess_sequence=self.layer_postprocess_sequence,
                                           dropout=self.dropout,
                                           scaled=self.scaled,
                                           ff_size=self.ff_size,
                                           mode=self.mode,
                                           dvc=self.dvc,
                                           max_seq_len=self.max_seq_len,
                                           pe=self.pe,
                                           k_proj=self.k_proj,
                                           q_proj=self.q_proj,
                                           v_proj=self.v_proj,
                                           r_proj=self.r_proj,
                                           attn_ff=self.attn_ff,
                                           ff_activate=self.ff_activate,
                                           )

        self.output_dropout = nn.Dropout(self.dropout['output'])

        self.output = nn.Linear(self.hidden_size,self.label_size)
        if self.self_supervised:
            self.output_self_supervised = nn.Linear(self.hidden_size,len(vocabs['char']))
            print('self.output_self_supervised:{}'.format(self.output_self_supervised.weight.size()))
        self.crf = get_crf_zero_init(self.label_size)
        self.loss_func = nn.CrossEntropyLoss(ignore_index=-100)
    def forward(self, chars, bigrams, seq_len, target, chars_target=None):
        # print('**self.training: {} **'.format(self.training))
        batch_size = chars.size(0)
        max_seq_len = chars.size(1)
        chars_embed = self.char_embed(chars)
        if self.use_bigram:
            bigrams_embed = self.bigram_embed(bigrams)
            embedding = torch.cat([chars_embed,bigrams_embed],dim=-1)
        else:
            embedding = chars_embed
        if self.embed_dropout_pos == '0':
            embedding = self.embed_dropout(embedding)

        embedding = self.w_proj(embedding)
        if self.embed_dropout_pos == '1':
            embedding = self.embed_dropout(embedding)

        if self.use_abs_pos:
            embedding = self.pos_encode(embedding)

        if self.embed_dropout_pos == '2':
            embedding = self.embed_dropout(embedding)


        encoded = self.encoder(embedding,seq_len)

        if hasattr(self,'output_dropout'):
            encoded = self.output_dropout(encoded)

        pred = self.output(encoded)

        mask = seq_len_to_mask(seq_len).bool()

        if self.mode['debug']:
            print('debug mode:finish!')
            exit(1208)
        if self.training:
            loss = self.crf(pred, target, mask).mean(dim=0)
            if self.self_supervised:
                # print('self supervised loss added!')
                chars_pred = self.output_self_supervised(encoded)
                chars_pred = chars_pred.view(size=[batch_size*max_seq_len,-1])
                chars_target = chars_target.view(size=[batch_size*max_seq_len])
                self_supervised_loss = self.loss_func(chars_pred,chars_target)
                # print('self_supervised_loss:{}'.format(self_supervised_loss))
                # print('supervised_loss:{}'.format(loss))
                loss += self_supervised_loss
            return {'loss': loss}
        else:
            pred, path = self.crf.viterbi_decode(pred, mask)
            result = {'pred': pred}
            if self.self_supervised:
                chars_pred = self.output_self_supervised(encoded)
                result['chars_pred'] = chars_pred

            return result


    # def train(self,mode=True):
    #     print('model mode get train ! mode:{}'.format(mode))
    #     super().train(mode)
    #
    # def eval(self):
    #     print('model mode get eval !')
    #     super().eval()